# NEXUS MD Search Engine — Build Report

**Generated:** 2026-05-21
**Source File:** `NEXUS-MD-1779391545198.xlsx` / Sheet: `Sheet1`
**Mode:** Local — No external API, No GitHub push, No Excel modification

---

## 1. Files Created

| File | Size | Description |
|------|------|-------------|
| `import_nexus_md.py` | — | Importer: reads Excel → produces JSON + SQLite |
| `nexus_md_index.json` | ~45 KB | Structured JSON index (83 records + anomaly log) |
| `nexus_md_search.sqlite` | ~120 KB | SQLite database with FTS5 full-text search |
| `search_nexus_md.py` | — | Search CLI with filters, highlight, verbose mode |
| `NEXUS_MD_SEARCH_REPORT.md` | — | This report |

> **Excel source file was not modified.**

---

## 2. Record Count by Type

| Type | Count | Description |
|------|------:|-------------|
| `DEC` | 15 | Architectural Decision Records |
| `ARCH` | 14 | Architecture Decisions (ARCH-012 → ARCH-025) |
| `SIGNAL` | 8 | Observability / Telemetry Signals |
| `REPO_CLASS` | 8 | Repository Classification Categories |
| `CV_RULE` | 7 | Recruitment CV Cover Knowledge Rules |
| `REPO_STRATEGIC` | 6 | P1 Strategic Repositories |
| `FORBIDDEN` | 6 | Forbidden Directions / Anti-Patterns |
| `STAGE` | 5 | Decision Progression Stages (1–5) |
| `TRUTH_TYPE` | 4 | Truth Classification Definitions |
| `STATUS` | 4 | Current NEXUS State / Priority / Blockers / Next Action |
| `DAM` | 4 | Decision Authority Matrix entries |
| `RH_LOG` | 2 | Recruitment Hub Implementation Log entries |
| **TOTAL** | **83** | — |

---

## 3. JSON Record Schema

Every record follows this exact schema:

```json
{
  "id": "ARCH-025",
  "type": "ARCH",
  "title": "Sensitive Execution Human Approval",
  "content": "Full searchable text...",
  "reason": "AI recommendations must not automatically execute...",
  "impact": "Critical",
  "truth_status": "ACTIVE",
  "related_layers": ["Compliance", "Safety", "Governance"],
  "tags": ["arch", "compliance", "safety", "governance"],
  "source_file": "NEXUS-MD-1779391545198.xlsx",
  "source_sheet": "Sheet1",
  "source_row": 29,
  "source_columns": ["A", "B", "C", "D", "E"],
  "created_or_updated_at": "2026-05-20"
}
```

---

## 4. SQLite Structure

### Table: `nexus_md_records`
Stores all 83 records with full metadata + raw `json_data` column.

### FTS5 Virtual Table: `nexus_md_records_fts`
Indexed fields: `id`, `type`, `title`, `content`, `reason`, `impact`, `related_layers`, `tags`

### View: `nexus_md_stats`
Aggregated count per type — used by `--stats` flag.

**Supported search modes:**
- Keyword full-text (BM25 ranked)
- Direct ID lookup: `ARCH-025`, `DEC-007`, `DAM-002`
- `--type` filter: `ARCH`, `DEC`, `DAM`, `SIGNAL`, `CV_RULE`, etc.
- `--impact` filter: `Critical`, `High`, `Medium`, `Low`
- `--layer` filter: `Governance`, `Recruitment`, `Safety`, etc.
- `--status` filter: `STABLE`, `EXPERIMENTAL`, `ACTIVE`
- `--json` flag: raw JSON output for API/pipeline use

---

## 5. Excel Anomalies Detected

**Total anomalies: 2**
No data was deleted. All anomalies are reported only.

| Excel Row | Issue | Action Taken |
|-----------|-------|--------------|
| Row 30 | Duplicate ARCH ID `ARCH-017` — already recorded at row 21 | Kept first valid record; skipped duplicate |
| Row 31 | Duplicate ARCH ID `ARCH-018` — already recorded at row 22 | Kept first valid record; skipped duplicate |

**Additional structural observations:**
- Rows 32–40: Multiple cells contain unevaluated `={...}` array formulas. openpyxl reads these as formula strings. Affected data in those cells was excluded from indexing; surrounding clean cells were preserved.
- Rows 102–104: `=IF(ROW()=126,...)` conditional array formulas — not evaluated. Static data in adjacent columns (safety incidents, 95%, HR review, Stage 3) was captured.
- Row 17: ArrayFormula objects in ARCH-017 metadata block — metadata unavailable from that row; clean record sourced from row 21 instead.
- Column spread: The Excel uses a horizontal layout (up to column 816 = DXE). Multiple logical tables exist side-by-side in the same sheet. All recognized patterns were extracted.
- Sheet `BACKUP_BEFORE_ARCH_UPDATE_2026_` was intentionally ignored per instructions.

---

## 6. Validation — 5 Search Results

### Search 1: `human approval`
| # | ID | Type | Title |
|---|----|----- |-------|
| 1 | ARCH-025 | ARCH | Sensitive Execution Human Approval (**Critical**) |
| 2 | DAM-001 | DAM | Safety Shutdown — Human Required |
| 3 | DAM-003 | DAM | Emergency Procurement — Approval Required |
| 4 | DAM-004 | DAM | Worker Suspension — HR + Ops Approval |
| 5 | FBD-004 | FORBIDDEN | Static employee records |

### Search 2: `attendance`
| # | ID | Type | Title |
|---|----|----- |-------|
| 1 | DAM-002 | DAM | Attendance Reminder — Autonomous/Automatic |
| 2 | OMG-20260520-001 | RH_LOG | Omega Architecture — Fleet P1 / Attendance P0 |
| 3 | STATUS-BLOCKERS | STATUS | NEXUS Current Blockers (references Attendance P0) |

### Search 3: `recruitment cv cover`
| # | ID | Type | Title |
|---|----|----- |-------|
| 1 | ARCH-017 | ARCH | Recruitment Hub Import Memory Standard |
| 2 | ARCH-018 | ARCH | Candidate Detail Card / CV Cover View |
| 3 | ARCH-024 | ARCH | Manual Operational Intake Routing |
| 4 | SIG-003 | SIGNAL | Failed Automations |
| 5 | CVR-SOURCE | CV_RULE | SOURCE TRUTH Rule |

### Search 4: `entity purity`
| # | ID | Type | Title |
|---|----|----- |-------|
| 1 | ARCH-013 | ARCH | Decision Calibration Phase Initialized |
| 2 | DEC-007 | DEC | **Entity Purity Law** — STABLE |
| 3 | DEC-016 | DEC | Unique Identifier Synchronization Rule |

### Search 5: `ARCH-025`
| # | ID | Type | Title |
|---|----|----- |-------|
| 1 | ARCH-025 | ARCH | Sensitive Execution Human Approval — Critical |

---

## 7. Run Commands

### Rebuild index (after Excel update):
```bash
python3 import_nexus_md.py
```

### Search examples:
```bash
python3 search_nexus_md.py "human approval"
python3 search_nexus_md.py "ARCH-025"
python3 search_nexus_md.py "attendance"
python3 search_nexus_md.py "entity purity"
python3 search_nexus_md.py "recruitment cv cover"

# With filters
python3 search_nexus_md.py "governance" --type ARCH
python3 search_nexus_md.py "critical" --impact Critical
python3 search_nexus_md.py "memory" --type DEC --status STABLE
python3 search_nexus_md.py "telegram" --layer "Intelligence"

# Output formats
python3 search_nexus_md.py "ARCH-025" --verbose      # show source row/cols
python3 search_nexus_md.py "ARCH-025" --json         # raw JSON output

# Index info
python3 search_nexus_md.py --stats
python3 search_nexus_md.py --types
```

---

## 8. Search Engine Status

| Check | Result |
|-------|--------|
| JSON index built | ✅ 83 records |
| SQLite FTS5 built | ✅ `nexus_md_records` + `nexus_md_records_fts` |
| Source traceability | ✅ Every record has `source_row` + `source_columns` |
| Anomaly detection | ✅ 2 duplicate ARCH IDs reported |
| Malformed rows reported | ✅ ArrayFormula / formula-string rows logged in `anomalies` |
| Excel unmodified | ✅ Read-only load confirmed |
| No external API | ✅ 100% local |
| No GitHub push | ✅ No git operations performed |
| Direct ID lookup | ✅ `ARCH-025` → exact match |
| Keyword search | ✅ BM25 ranked FTS5 |
| Type filter | ✅ `--type ARCH / DEC / DAM / SIGNAL / ...` |
| Impact filter | ✅ `--impact Critical / High` |
| Layer filter | ✅ `--layer "Governance"` |
| Truth status filter | ✅ `--status STABLE / EXPERIMENTAL` |
| JSON output mode | ✅ `--json` flag |
| **READY FOR USE** | ✅ |

---

*Report generated by NEXUS MD Search Engine Build — 2026-05-21*
