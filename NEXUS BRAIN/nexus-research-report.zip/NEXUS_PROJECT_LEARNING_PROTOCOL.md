# NEXUS Project Learning Protocol

**Version:** 1.0
**Date:** 2026-05-22
**Status:** ACTIVE

---

## Purpose

This protocol defines how NEXUS learns from every project it operates in, extracts reusable intelligence, and evolves its capabilities — while maintaining strict separation between client-specific data and NEXUS Core.

NEXUS does not just execute. It learns.
But it never mixes Omega's data with NEXUS Core. Never promotes anything without human approval.

---

## Separation Law (Mandatory)

```
┌─────────────────────────────────────────────────────────────────────┐
│  Everything that enters NEXUS must be classified before storage.    │
└─────────────────────────────────────────────────────────────────────┘

Input → Classify → Route

PROJECT_SPECIFIC     → Omega Business Pack (or client pack)
CLIENT_CONFIGURATION → Client Pack
REUSABLE_CAPABILITY  → Pending Capability Patch → Human Approval → Registry
CORE_RULE            → Pending Core Patch → Human Approval → NEXUS Core Memory
COMPLIANCE_GUARD     → Pending Guard Patch → Human Approval → Guard Layer
BUSINESS_PLAYBOOK    → Business Intake Knowledge Base
DATA_IMPORT_PATTERN  → Capability (Data Intake domain)
UI_PATTERN           → UI Library candidate
AUTOMATION_PATTERN   → Automation Library candidate
```

**Non-negotiable:** If it cannot be classified, it is assumed PROJECT_SPECIFIC until reviewed.

---

## Classification Types

### 1. PROJECT_SPECIFIC
Data, names, or configurations that are unique to one client.
- Omega apartment names → Omega Business Pack
- Specific employee lists → Omega Business Pack
- Client-specific salary structures → Client Pack
- **Never enters NEXUS Core. Ever.**

### 2. REUSABLE_CAPABILITY
An operational pattern that can work for 2+ industries.
- Fleet tracking from Omega → can work in any company with vehicles
- Recruitment import → works for any sector hiring people
- Attendance parsing → universal
- **Creates a Pending Capability Patch. Requires approval.**

### 3. CORE_RULE
A fundamental architectural or governance rule.
- "Every Excel import must have a preview before DB write"
- "Duplicates must be reported, never auto-deleted"
- "Human approval required for bulk operations"
- **Creates a Pending ARCH Patch. Requires review and ARCH-ID assignment.**

### 4. CLIENT_CONFIGURATION
How a generic capability is configured for a specific client.
- Omega uses 3 vehicles per project → stored in Omega Config Pack
- Field mapping for Omega's Excel format → stored in Omega Config Pack
- **Stays in Client Pack. Generic capability stays in Core.**

### 5. BUSINESS_PLAYBOOK
How NEXUS enters a new sector.
- "For sweets factories, start with Inventory + Production + Attendance"
- "For construction, start with Manpower + Fleet + Accommodation"
- **Added to Business Intake knowledge base.**

### 6. DATA_IMPORT_PATTERN
How data enters NEXUS from files.
- "Biometric export always has duplicates due to multiple check-ins"
- "Arabic column headers need normalization before mapping"
- **Becomes a Data Intake capability.**

### 7. UI_PATTERN
Reusable UI component or layout.
- "Show candidate photo + name + position + 3 key facts on one card"
- **UI Library candidate. Needs design review.**

### 8. AUTOMATION_PATTERN
A repeatable automated process.
- "Daily manpower report auto-generates at 11pm"
- **Automation Library candidate. Requires scheduling spec.**

### 9. COMPLIANCE_GUARD
A rule that prevents unsafe or irreversible operations.
- "Never write to DB without preview"
- "Never delete attendance records without audit log"
- **Guard Layer candidate. Highest priority. Fast-tracked to review.**

---

## The Learning Flow

```
Step 1: Project Team submits update
  "سجل اللي اتعلمناه من تحديث Fleet P1 في أوميجا"

Step 2: project_learning_ingest.py classifies the update
  → Classification: REUSABLE_CAPABILITY
  → Domain: Fleet
  → Matched keywords: [fleet, vehicle, maintenance]

Step 3: System checks for similar existing capabilities
  → If similar exists: suggest MERGE (shows diff)
  → If new: create Pending Capability Patch

Step 4: Pending Patch created in nexus_capabilities.sqlite
  → Status: PENDING
  → No capability created yet

Step 5: Human Reviews
  python capability_promoter.py --diff PATCH-ID
  python capability_promoter.py --approve PATCH-ID

Step 6: After Approval Only
  → nexus_capabilities.json updated
  → SQLite registry updated
  → Capability officially active

Step 7: Capability can now be reused
  python capability_registry.py --search "fleet factory"
  python capability_registry.py --reusable-for Construction
```

---

## Promotion Ladder

```
IDEA → DRAFT → PILOT → STABLE → REUSABLE_TEMPLATE → CORE_CAPABILITY
```

| From | To | Who approves | Criteria |
|------|----|-------------|----------|
| IDEA | DRAFT | Lead Developer | Initial spec written |
| DRAFT | PILOT | Technical Lead | Implemented in one project |
| PILOT | STABLE | Architecture Team | Tested, documented, no major bugs |
| STABLE | REUSABLE_TEMPLATE | Product Lead | Abstracted, configurable, generic |
| REUSABLE_TEMPLATE | CORE_CAPABILITY | CTO / Decision Authority | Used in 2+ clients successfully |

**Skipping levels is not allowed without explicit approval note.**
**CORE_CAPABILITY requires typing 'PROMOTE' in the CLI to confirm.**

---

## What NEXUS Must Never Do

1. **Never auto-promote** — any classification-to-core pipeline without human step.
2. **Never mix** — Omega specific data with NEXUS generic schema.
3. **Never delete** client data without audit trail.
4. **Never overwrite** existing capability without showing diff first.
5. **Never skip** the preview step for any file-based intake.
6. **Never commit** learning to NEXUS Core based on one project alone (minimum: reviewed by 2 eyes).

---

## What Omega Teaches NEXUS

| Omega Learning | Classification | NEXUS Benefit |
|----------------|---------------|---------------|
| Fleet tracking implementation | REUSABLE_CAPABILITY | CAP-FLEET-001 |
| Recruitment Excel import flow | REUSABLE_CAPABILITY | CAP-REC-001 |
| Attendance deduplication logic | REUSABLE_CAPABILITY | CAP-ATT-001 |
| Accommodation occupancy tracking | REUSABLE_CAPABILITY | CAP-ACC-001 |
| Apartment names (شقة النيل، إلخ) | PROJECT_SPECIFIC | Stays in Omega Pack |
| Daily manpower report automation | REUSABLE_CAPABILITY | CAP-RPT-001 |
| Excel preview before DB write rule | COMPLIANCE_GUARD | ARCH-025 enforcement |
| Human approval for bulk operations | COMPLIANCE_GUARD | CAP-GOV-001 |

---

## Business Intake Protocol (Mode 2)

When someone says: "أنا في مصنع حلويات، نكسس يدخل يشتغل إزاي؟"

NEXUS responds with:
1. **Sector detected**: Food Production / Sweets Factory
2. **Matching capabilities**: Attendance, Inventory, Production Orders, Recipe/BOM, Quality, Maintenance, Sales
3. **Files to request**:
   - Products list (أصناف المنتجات)
   - Raw materials list (مواد خام)
   - Recipes / BOM
   - Daily production log
   - Inventory snapshot
   - Attendance / shifts
   - Sales & orders
   - Returns / quality
   - Machine maintenance log
4. **First 30 days plan**:
   - Week 1-2: File Analyzer + field mapping
   - Week 2-3: Attendance + Manpower
   - Week 3-4: Inventory + Production
   - Month 2: Reporting + Alerts
5. **Missing capabilities**: (disclosed honestly — e.g. "Recipe BOM costing is DRAFT, not yet STABLE")
6. **Omega reusable**: Attendance ✅ | Manpower Report ✅ | Duplicate Detection ✅
7. **Not reusable from Omega**: Fleet (unless factory has delivery vehicles) | Accommodation (unless workers stay on-site)

---

## File Responsibilities

| File | Role |
|------|------|
| `project_learning_ingest.py` | Classify and process project updates |
| `nexus_capabilities.json` | Master capability registry (source of truth) |
| `nexus_capabilities.sqlite` | Searchable DB with FTS5 |
| `nexus_capability_schema.sql` | DB schema |
| `capability_registry.py` | Read/search capabilities |
| `capability_promoter.py` | Approve/reject/promote patches |

---

## Audit Trail

Every action is logged. Nothing is silent.

- `nexus_learning_sessions` — every ingest call
- `nexus_capability_patches` — every proposed change
- `nexus_capability_promotions` — every promotion event
- JSON file is always in sync with approved capabilities

The audit trail is immutable. Approved promotions are never deleted from the log.
