#!/usr/bin/env python3
"""
NEXUS Capability Promoter
Approves, rejects, or promotes capability patches.
Enforces Human Approval Guard — no capability is modified without this step.

Usage:
    python capability_promoter.py --list-patches          # show all pending patches
    python capability_promoter.py --approve PATCH-001     # approve a patch
    python capability_promoter.py --reject PATCH-001 --notes "reason"
    python capability_promoter.py --promote CAP-FLEET-001 --to STABLE
    python capability_promoter.py --diff PATCH-001        # show diff before approving
    python capability_promoter.py --history CAP-FLEET-001 # promotion history
"""

import json
import argparse
import sqlite3
import os
import sys
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_FILE = os.path.join(BASE_DIR, "nexus_capabilities.sqlite")
JSON_FILE = os.path.join(BASE_DIR, "nexus_capabilities.json")

# ANSI
R = "\033[0m"
BOLD = "\033[1m"
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
DIM = "\033[2m"

MATURITY_ORDER = [
    "IDEA", "DRAFT", "PILOT", "STABLE",
    "REUSABLE_TEMPLATE", "CORE_CAPABILITY", "DEPRECATED"
]


def get_db():
    if not os.path.exists(DB_FILE):
        print(f"{RED}ERROR: DB not found. Run capability_registry.py first to build it.{R}")
        sys.exit(1)
    con = sqlite3.connect(DB_FILE)
    con.row_factory = sqlite3.Row
    return con


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ── diff helpers ───────────────────────────────────────────────────────
def compute_diff(existing, proposed):
    """Return human-readable diff between existing capability and proposed data."""
    lines = []
    if not existing:
        lines.append("  NEW CAPABILITY — no existing record to compare.")
        for k, v in proposed.items():
            lines.append(f"  + {k}: {v}")
        return "\n".join(lines)

    existing = dict(existing)
    for k, v_new in proposed.items():
        v_old = existing.get(k, "")
        if isinstance(v_new, list):
            v_new_str = json.dumps(v_new, ensure_ascii=False)
        else:
            v_new_str = str(v_new or "")
        v_old_str = str(v_old or "")
        if v_new_str != v_old_str:
            lines.append(f"  FIELD: {k}")
            lines.append(f"    {RED}- {v_old_str[:120]}{R}")
            lines.append(f"    {GREEN}+ {v_new_str[:120]}{R}")
    if not lines:
        lines.append("  No differences detected.")
    return "\n".join(lines)


# ── patch operations ───────────────────────────────────────────────────
def list_patches(con, status=None):
    q = "SELECT * FROM nexus_capability_patches"
    params = []
    if status:
        q += " WHERE status=?"
        params.append(status)
    q += " ORDER BY created_at DESC"
    patches = con.execute(q, params).fetchall()

    if not patches:
        print(f"\n{GREEN}✅ No patches found.{R}\n")
        return

    label = f"Patches ({status or 'ALL'})"
    print(f"\n{BOLD}{'═'*70}{R}")
    print(f"{BOLD}  NEXUS Capability Patches — {label}{R}")
    print(f"{'═'*70}")

    for p in patches:
        status_color = GREEN if p["status"] == "APPROVED" else (
            RED if p["status"] == "REJECTED" else YELLOW)
        print(f"\n  {BOLD}{p['id']}{R}  [{p['patch_type']}]  "
              f"{status_color}{p['status']}{R}")
        print(f"  Capability: {p['capability_id'] or '(new)'}")
        print(f"  Project: {p['source_project']}  │  Classification: {p['classification']}")
        print(f"  Update: {p['source_update_text'][:100]}")
        print(f"  Created: {p['created_at']}")
        if p["reviewed_at"]:
            print(f"  Reviewed: {p['reviewed_at']} by {p['reviewed_by'] or '?'}")
        if p["notes"]:
            print(f"  Notes: {p['notes']}")
    print()


def show_diff(con, patch_id):
    patch = con.execute(
        "SELECT * FROM nexus_capability_patches WHERE id=?", (patch_id,)
    ).fetchone()
    if not patch:
        print(f"{RED}Patch not found: {patch_id}{R}")
        return False

    proposed = json.loads(patch["proposed_data"])
    cap_id = patch["capability_id"]
    existing = None
    if cap_id:
        existing = con.execute(
            "SELECT * FROM nexus_capabilities WHERE id=?", (cap_id,)
        ).fetchone()

    print(f"\n{BOLD}{'═'*70}{R}")
    print(f"{BOLD}  Diff for {patch_id}{R}  [{patch['patch_type']}]")
    print(f"{'═'*70}")
    print(f"  Capability: {cap_id or '(new)'}")
    print(f"  Source: {patch['source_project']}  │  Classification: {patch['classification']}")
    print(f"  Update: {patch['source_update_text']}")
    print(f"\n{BOLD}  Changes:{R}")
    print(compute_diff(existing, proposed))
    print()
    return True


def approve_patch(con, patch_id, reviewer="human", notes=""):
    patch = con.execute(
        "SELECT * FROM nexus_capability_patches WHERE id=?", (patch_id,)
    ).fetchone()
    if not patch:
        print(f"{RED}Patch not found: {patch_id}{R}")
        return

    if patch["status"] != "PENDING":
        print(f"{YELLOW}Patch {patch_id} is already {patch['status']}.{R}")
        return

    # Show diff first
    show_diff(con, patch_id)

    # Confirm
    confirm = input(f"{YELLOW}Approve patch {patch_id}? [y/N]: {R}").strip().lower()
    if confirm != "y":
        print(f"{DIM}Approval cancelled.{R}")
        return

    proposed = json.loads(patch["proposed_data"])
    patch_type = patch["patch_type"]
    ts = now()

    if patch_type == "NEW":
        # Insert new capability
        from capability_registry import _insert_capability, get_db
        cap_data = proposed
        cap_data["approval_status"] = "APPROVED"
        cap_data["created_at"] = cap_data.get("created_at") or ts[:10]
        cap_data["updated_at"] = ts[:10]
        _insert_capability(con, cap_data)

        # Log promotion
        cap_id = cap_data.get("id", patch_id)
        con.execute("""
            INSERT INTO nexus_capability_promotions
            (id, capability_id, from_maturity, to_maturity, patch_id, promoted_by, promoted_at, notes)
            VALUES (?,?,?,?,?,?,?,?)
        """, (
            f"PROMO-{ts.replace(' ','-').replace(':','')}",
            cap_id, "", cap_data.get("maturity", "DRAFT"),
            patch_id, reviewer, ts, notes
        ))

    elif patch_type == "UPDATE":
        cap_id = patch["capability_id"]
        set_clauses = []
        values = []
        for k, v in proposed.items():
            if k == "id":
                continue
            if isinstance(v, list):
                v = json.dumps(v, ensure_ascii=False)
            set_clauses.append(f"{k}=?")
            values.append(v)
        set_clauses.append("updated_at=?")
        values.append(ts[:10])
        values.append(cap_id)
        con.execute(
            f"UPDATE nexus_capabilities SET {','.join(set_clauses)} WHERE id=?", values
        )

    # Mark patch approved
    con.execute("""
        UPDATE nexus_capability_patches
        SET status='APPROVED', reviewed_by=?, reviewed_at=?, notes=?
        WHERE id=?
    """, (reviewer, ts, notes or patch["notes"], patch_id))

    # Sync JSON
    _sync_json(con)
    con.commit()
    print(f"\n{GREEN}✅ Patch {patch_id} APPROVED and applied.{R}\n")


def reject_patch(con, patch_id, reviewer="human", notes=""):
    patch = con.execute(
        "SELECT * FROM nexus_capability_patches WHERE id=?", (patch_id,)
    ).fetchone()
    if not patch:
        print(f"{RED}Patch not found: {patch_id}{R}")
        return
    ts = now()
    con.execute("""
        UPDATE nexus_capability_patches
        SET status='REJECTED', reviewed_by=?, reviewed_at=?, notes=?
        WHERE id=?
    """, (reviewer, ts, notes, patch_id))
    con.commit()
    print(f"\n{RED}✗ Patch {patch_id} REJECTED.{R}  Notes: {notes}\n")


def promote_capability(con, cap_id, to_maturity, reviewer="human", notes=""):
    cap = con.execute(
        "SELECT * FROM nexus_capabilities WHERE id=?", (cap_id,)
    ).fetchone()
    if not cap:
        print(f"{RED}Capability not found: {cap_id}{R}")
        return

    from_maturity = cap["maturity"]
    if to_maturity not in MATURITY_ORDER:
        print(f"{RED}Invalid maturity: {to_maturity}. Must be one of: {', '.join(MATURITY_ORDER)}{R}")
        return

    # Guard: promoting to CORE_CAPABILITY requires explicit confirmation
    if to_maturity == "CORE_CAPABILITY":
        print(f"\n{YELLOW}{BOLD}⚠  WARNING: Promoting to CORE_CAPABILITY is irreversible.{R}")
        print(f"  Capability: {cap_id} — {cap['name']}")
        print(f"  From: {from_maturity}  →  To: {to_maturity}")
        confirm = input(f"\n{YELLOW}Are you sure? Type 'PROMOTE' to confirm: {R}").strip()
        if confirm != "PROMOTE":
            print(f"{DIM}Promotion cancelled.{R}")
            return

    ts = now()
    con.execute("""
        UPDATE nexus_capabilities
        SET maturity=?, updated_at=?
        WHERE id=?
    """, (to_maturity, ts[:10], cap_id))

    patch_id = f"PROMO-{cap_id}-{ts[:10]}"
    con.execute("""
        INSERT INTO nexus_capability_promotions
        (id, capability_id, from_maturity, to_maturity, patch_id, promoted_by, promoted_at, notes)
        VALUES (?,?,?,?,?,?,?,?)
    """, (patch_id, cap_id, from_maturity, to_maturity, patch_id, reviewer, ts, notes))

    _sync_json(con)
    con.commit()
    print(f"\n{GREEN}✅ {cap_id} promoted: {from_maturity} → {to_maturity}{R}\n")


def show_history(con, cap_id):
    rows = con.execute("""
        SELECT * FROM nexus_capability_promotions
        WHERE capability_id=? ORDER BY promoted_at ASC
    """, (cap_id,)).fetchall()

    if not rows:
        print(f"\n{DIM}No promotion history for {cap_id}.{R}\n")
        return

    print(f"\n{BOLD}  Promotion History — {cap_id}{R}")
    print(f"  {'─'*50}")
    for r in rows:
        print(f"  {r['promoted_at'][:10]}  {r['from_maturity'] or '(new)'} → {r['to_maturity']}"
              f"  by {r['promoted_by']}")
        if r["notes"]:
            print(f"    Notes: {r['notes']}")
    print()


def _sync_json(con):
    """Write approved capabilities back to nexus_capabilities.json."""
    caps = con.execute(
        "SELECT * FROM nexus_capabilities ORDER BY id"
    ).fetchall()
    patches = con.execute(
        "SELECT * FROM nexus_capability_patches WHERE status='PENDING' ORDER BY created_at"
    ).fetchall()

    def row_to_dict(r):
        d = dict(r)
        for list_field in ["reusable_for", "required_data", "suggested_tables",
                           "suggested_ui", "automation_opportunities", "risks",
                           "guards", "related_arch", "related_decisions"]:
            if d.get(list_field) and isinstance(d[list_field], str):
                try:
                    d[list_field] = json.loads(d[list_field])
                except Exception:
                    pass
        return d

    data = {
        "meta": {
            "version": "1.0",
            "updated_at": datetime.now().strftime("%Y-%m-%d"),
            "total_capabilities": len(caps),
        },
        "capabilities": [row_to_dict(r) for r in caps],
        "pending_patches": [row_to_dict(r) for r in patches],
    }

    with open(JSON_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


# ── main ───────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="NEXUS Capability Promoter")
    parser.add_argument("--list-patches", action="store_true")
    parser.add_argument("--pending", action="store_true")
    parser.add_argument("--approved", action="store_true")
    parser.add_argument("--approve", metavar="PATCH_ID")
    parser.add_argument("--reject", metavar="PATCH_ID")
    parser.add_argument("--diff", metavar="PATCH_ID")
    parser.add_argument("--promote", metavar="CAP_ID")
    parser.add_argument("--to", metavar="MATURITY")
    parser.add_argument("--history", metavar="CAP_ID")
    parser.add_argument("--reviewer", default="human")
    parser.add_argument("--notes", default="")
    args = parser.parse_args()

    con = get_db()

    if args.list_patches or args.pending:
        list_patches(con, status="PENDING" if args.pending else None)
    elif args.approved:
        list_patches(con, status="APPROVED")
    elif args.diff:
        show_diff(con, args.diff)
    elif args.approve:
        approve_patch(con, args.approve, reviewer=args.reviewer, notes=args.notes)
    elif args.reject:
        reject_patch(con, args.reject, reviewer=args.reviewer, notes=args.notes)
    elif args.promote:
        if not args.to:
            print(f"{RED}--to MATURITY is required with --promote{R}")
            sys.exit(1)
        promote_capability(con, args.promote, args.to, reviewer=args.reviewer, notes=args.notes)
    elif args.history:
        show_history(con, args.history)
    else:
        parser.print_help()

    con.close()


if __name__ == "__main__":
    main()
