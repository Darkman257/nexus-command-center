#!/usr/bin/env python3
"""
import_nexus_md.py
─────────────────
NEXUS MD Search Engine — Importer
Reads NEXUS-MD-1779391545198.xlsx (Sheet1 only),
extracts structured records, and produces:
  • nexus_md_index.json
  • nexus_md_search.sqlite  (FTS5)

Rules:
  - Never modifies the source Excel file.
  - Reports anomalies; never deletes data.
  - No external API calls.
  - Full source traceability per record.
"""

import json
import sqlite3
import os
import re
from datetime import datetime, date
from collections import defaultdict

from openpyxl import load_workbook
from openpyxl.worksheet.formula import ArrayFormula

# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────
XL_PATH    = "NEXUS-MD-1779391545198.xlsx"
JSON_PATH  = "nexus_md_index.json"
DB_PATH    = "nexus_md_search.sqlite"
SHEET_NAME = "Sheet1"

SOURCE_FILE = "NEXUS-MD-1779391545198.xlsx"

# Column letter helper (0-indexed → "A", "B", …)
def col_letter(idx):
    letters = ""
    idx += 1
    while idx:
        idx, rem = divmod(idx - 1, 26)
        letters = chr(65 + rem) + letters
    return letters

# ─────────────────────────────────────────────
# RAW LOAD
# ─────────────────────────────────────────────

def load_sheet(path, sheet_name):
    """
    Returns list of dicts: { col_idx(int): raw_value }
    Preserves row index (1-based, matching Excel rows).
    Also returns anomalies list.
    """
    wb = load_workbook(path, read_only=False, data_only=True)
    ws = wb[sheet_name]

    rows = []        # list of (excel_row_num, {col_idx: value})
    anomalies = []   # list of anomaly dicts

    for row_obj in ws.iter_rows(values_only=False):
        excel_row = row_obj[0].row
        cell_map = {}
        row_anomalies = []

        for cell in row_obj:
            cidx = cell.column - 1   # 0-indexed
            raw  = cell.value

            if raw is None:
                continue

            # Detect ArrayFormula
            if isinstance(raw, ArrayFormula):
                row_anomalies.append({
                    "excel_row": excel_row,
                    "col": col_letter(cidx),
                    "issue": "ArrayFormula — value not calculated by openpyxl",
                    "raw": str(raw)[:120],
                })
                continue

            # Detect formula strings
            sv = str(raw).strip()
            if sv.startswith("={") or sv.startswith("=IF(") or sv.startswith("=COLUMN"):
                row_anomalies.append({
                    "excel_row": excel_row,
                    "col": col_letter(cidx),
                    "issue": "Unevaluated formula string",
                    "raw": sv[:120],
                })
                # Keep in cell_map as-is for traceability
                cell_map[cidx] = sv
                continue

            if isinstance(raw, (datetime, date)):
                cell_map[cidx] = raw.strftime("%Y-%m-%d")
            else:
                cell_map[cidx] = str(raw).strip() if str(raw).strip() else None
                if cell_map[cidx] is None:
                    del cell_map[cidx]
                    continue

        if cell_map:
            rows.append((excel_row, cell_map))
        if row_anomalies:
            anomalies.extend(row_anomalies)

    wb.close()
    return rows, anomalies


def val(row_dict, col):
    v = row_dict.get(col)
    if not v:
        return ""
    s = str(v).strip()
    if s.startswith("={") or s.startswith("=IF(") or s.startswith("=COLUMN"):
        return ""
    return s

def is_arch(s): return bool(re.match(r'^ARCH-\d{3}$', s))
def is_dec(s):  return bool(re.match(r'^DEC-\d{3}$',  s))
def is_dam(s):  return bool(re.match(r'^DAM-\d{3}$',  s))

def make_record(id_, type_, title, content, excel_row, col_indices, extra=None):
    r = {
        "id":               id_,
        "type":             type_,
        "title":            title,
        "content":          content,
        "reason":           "",
        "impact":           "",
        "truth_status":     "",
        "related_layers":   [],
        "tags":             [],
        "source_file":      SOURCE_FILE,
        "source_sheet":     SHEET_NAME,
        "source_row":       excel_row,
        "source_columns":   [col_letter(c) for c in sorted(set(col_indices))],
        "created_or_updated_at": datetime.now().strftime("%Y-%m-%d"),
    }
    if extra:
        for k, v2 in extra.items():
            if k in r:
                r[k] = v2
            else:
                r[k] = v2
    return r


# ─────────────────────────────────────────────
# EXTRACTORS
# ─────────────────────────────────────────────

def extract_arch(rows):
    records = []
    seen_ids = {}
    anomalies = []

    for (excel_row, row) in rows:
        a0 = val(row, 0)
        if not is_arch(a0):
            continue

        date_val   = val(row, 1)
        title      = val(row, 2)
        reason     = val(row, 3)
        impact     = val(row, 4)

        # Gather related layers from col 5 onwards (up to col 22)
        layers = []
        for ci in range(5, 23):
            lv = val(row, ci)
            if lv and not is_arch(lv) and not is_dec(lv) and len(lv) < 60:
                layers.append(lv)
        layers = layers[:6]

        # Detect duplicate ARCH ID
        if a0 in seen_ids:
            anomalies.append({
                "excel_row": excel_row,
                "issue": f"Duplicate ARCH ID {a0} — already seen at row {seen_ids[a0]}",
                "action": "Skipped duplicate; keeping first occurrence",
            })
            continue

        # Detect if row looks like a formula-fill (all cols have same value = ARCH-017 pattern)
        unique_vals = set(row.values())
        if len(unique_vals) == 1 and a0 in unique_vals:
            anomalies.append({
                "excel_row": excel_row,
                "issue": f"Row {excel_row}: All columns contain only '{a0}' — likely formula/merge error",
                "action": "Recorded single clean record with empty metadata",
            })
            r = make_record(
                a0, "ARCH",
                title or f"[Formula Error — {a0}]",
                f"{a0}: Metadata unavailable due to formula/merge error in source.",
                excel_row, list(row.keys()),
                extra={
                    "reason": "[ANOMALY: formula fill]",
                    "impact": "",
                    "truth_status": "ANOMALY",
                    "related_layers": [],
                    "tags": ["arch", "anomaly", "formula-error"],
                    "created_or_updated_at": date_val or datetime.now().strftime("%Y-%m-%d"),
                }
            )
            seen_ids[a0] = excel_row
            records.append(r)
            continue

        content = f"{title}. Reason: {reason}. Impact: {impact}."
        if layers:
            content += f" Layers: {', '.join(layers)}."

        r = make_record(
            a0, "ARCH", title, content,
            excel_row, list(row.keys()),
            extra={
                "reason":         reason,
                "impact":         impact,
                "truth_status":   "ACTIVE",
                "related_layers": layers,
                "tags":           ["arch"] + [l.lower().replace(" ", "-") for l in layers],
                "created_or_updated_at": date_val or datetime.now().strftime("%Y-%m-%d"),
            }
        )
        seen_ids[a0] = excel_row
        records.append(r)

    return records, anomalies


def extract_dec(rows):
    records = []
    seen = set()

    # Search all cols for DEC-NNN
    for (excel_row, row) in rows:
        for base_col in sorted(row.keys()):
            v = val(row, base_col)
            if not is_dec(v):
                continue
            if v in seen:
                continue

            # Gather surrounding cols
            title        = val(row, base_col+1) or val(row, base_col+2)
            truth_status = val(row, base_col+2) or val(row, base_col+3)
            rationale    = val(row, base_col+3) or val(row, base_col+4)
            solution     = val(row, base_col+4) or val(row, base_col+5)
            problem      = val(row, base_col+5) or val(row, base_col+6)
            rejected     = val(row, base_col+6) or val(row, base_col+7)

            # title should not be a date
            if title and re.match(r'^\d{4}-\d{2}-\d{2}', title):
                title = val(row, base_col+2)

            ts_clean = truth_status if truth_status in ("STABLE","EXPERIMENTAL","DEPRECATED","ACTIVE") else ""

            content = f"{title}. Status: {ts_clean}. Rationale: {rationale}. Solution: {solution}. Problem: {problem}. Rejected alt: {rejected}."
            col_indices = [base_col + i for i in range(8) if val(row, base_col+i)]

            r = make_record(
                v, "DEC", title or v, content,
                excel_row, col_indices,
                extra={
                    "reason":           rationale,
                    "impact":           "",
                    "truth_status":     ts_clean,
                    "related_layers":   [],
                    "tags":             ["dec", "adr", ts_clean.lower()],
                    "rationale":        rationale,
                    "chosen_solution":  solution,
                    "context_problem":  problem,
                    "rejected_alternatives": rejected,
                }
            )
            seen.add(v)
            records.append(r)

    # Sort by DEC-NNN
    records.sort(key=lambda x: int(x["id"].split("-")[1]))
    return records


def extract_dam(rows):
    records = []
    seen = set()

    for (excel_row, row) in rows:
        for base_col in range(0, 25):
            v = val(row, base_col)
            if not is_dam(v):
                continue
            if v in seen:
                continue

            dec_type   = val(row, base_col+1)
            authority  = val(row, base_col+2)
            exec_mode  = val(row, base_col+3)
            constraints= val(row, base_col+4)
            stakeholder= val(row, base_col+5)

            content = (f"{v}: {dec_type}. Authority: {authority}. "
                       f"Mode: {exec_mode}. Constraints: {constraints}. "
                       f"Stakeholder: {stakeholder}.")

            r = make_record(
                v, "DAM", dec_type or v, content,
                excel_row, [base_col+i for i in range(6)],
                extra={
                    "reason":             constraints,
                    "impact":             authority,
                    "truth_status":       "ACTIVE",
                    "related_layers":     [stakeholder] if stakeholder else [],
                    "tags":               ["dam", "guardrail", "governance",
                                           exec_mode.lower().replace(" ","-")],
                    "authority_level":    authority,
                    "execution_mode":     exec_mode,
                    "constraints":        constraints,
                    "primary_stakeholder":stakeholder,
                }
            )
            seen.add(v)
            records.append(r)

    records.sort(key=lambda x: int(x["id"].split("-")[1]))
    return records


def extract_truth_types(rows):
    TYPE_MAP = {
        "**SOURCE TRUTH**":  ("TRUTH-SOURCE",   "SOURCE TRUTH",    "TRUTH_TYPE"),
        "**DERIVED TRUTH**": ("TRUTH-DERIVED",  "DERIVED TRUTH",   "TRUTH_TYPE"),
        "**INFERENCE**":     ("TRUTH-INFERENCE","INFERENCE",       "TRUTH_TYPE"),
        "**UI PROJECTION**": ("TRUTH-UI",       "UI PROJECTION",   "TRUTH_TYPE"),
    }
    records = []
    seen = set()
    for (excel_row, row) in rows:
        key = val(row, 0)
        if key in TYPE_MAP and key not in seen:
            tid, label, typ = TYPE_MAP[key]
            desc    = val(row, 1)
            example = val(row, 2)
            content = f"{label}: {desc}. Example field: {example}."
            r = make_record(
                tid, "TRUTH_TYPE", label, content,
                excel_row, [0,1,2],
                extra={
                    "reason":         desc,
                    "impact":         "Global",
                    "truth_status":   "STABLE",
                    "related_layers": ["ALL"],
                    "tags":           ["truth", "classification", label.lower().replace(" ","_")],
                    "description":    desc,
                    "example_field":  example,
                }
            )
            seen.add(key)
            records.append(r)
    return records


def extract_signals(rows):
    """
    Signals appear in row 1 cols 59–114 in groups of 7:
    [signal_name, meaning, status, value, threshold, escalation_rule, truth_status]
    """
    records = []
    if not rows:
        return records

    _, row = rows[0]   # first data row (Excel row 1)
    signal_counter = 0
    col = 59
    HEADERS = {"Signal","Meaning","Status","Value","Threshold","Escalation Rule","Truth Status"}

    while col < 120:
        name = val(row, col)
        if not name or name in HEADERS:
            col += 1
            continue

        meaning    = val(row, col+1)
        status     = val(row, col+2)
        value      = val(row, col+3)
        threshold  = val(row, col+4)
        escalation = val(row, col+5)
        truth_s    = val(row, col+6)

        if not meaning:
            col += 1
            continue

        signal_counter += 1
        sig_id = f"SIG-{signal_counter:03d}"
        content = (f"Signal: {name}. Meaning: {meaning}. Status: {status}. "
                   f"Value: {value}. Threshold: {threshold}. "
                   f"Escalation: {escalation}. Truth: {truth_s}.")

        r = make_record(
            sig_id, "SIGNAL", name, content,
            1, list(range(col, col+7)),
            extra={
                "reason":           meaning,
                "impact":           threshold,
                "truth_status":     truth_s,
                "related_layers":   ["Observability"],
                "tags":             ["signal","telemetry","observability",
                                     truth_s.lower(), status.lower()],
                "current_value":    value,
                "threshold":        threshold,
                "escalation_rule":  escalation,
            }
        )
        records.append(r)
        col += 7

    return records


def extract_forbidden(rows):
    records = []
    for (excel_row, row) in rows:
        if val(row, 0) != "FORBIDDEN DIRECTION (Anti-Patterns)":
            continue
        if not val(row, 3):
            continue   # header/empty repeat rows

        groups = []
        for base in [3, 6, 9, 12, 15, 18, 702]:
            name    = val(row, base)
            reason  = val(row, base+1)
            arch_id = val(row, base+2)
            if name and reason and not name.startswith("FORBIDDEN"):
                groups.append((name, reason, arch_id))

        for i, (name, reason, arch_id) in enumerate(groups):
            fid = f"FBD-{len(records)+1:03d}"
            content = f"FORBIDDEN: {name}. Risk/Reason: {reason}. ARCH reference: {arch_id}."
            r = make_record(
                fid, "FORBIDDEN", name, content,
                excel_row, list(row.keys()),
                extra={
                    "reason":         reason,
                    "impact":         "Architecture Debt / System Corruption",
                    "truth_status":   "ENFORCED",
                    "related_layers": [arch_id] if arch_id else [],
                    "tags":           ["forbidden","anti-pattern","architecture",
                                       name.lower().replace(" ","-")],
                    "arch_reference": arch_id,
                }
            )
            records.append(r)
        break  # only one full row has all entries

    return records


def extract_repo(rows):
    records = []
    # Category row: col0=Communication Runtime, col2=Agent Architecture, …
    for (excel_row, row) in rows:
        if val(row,0) == "Communication Runtime" and val(row,2) == "Agent Architecture":
            cats = [(val(row,i), val(row,i+1)) for i in range(0,16,2) if val(row,i)]
            for j, (cat, desc) in enumerate(cats):
                if cat:
                    records.append(make_record(
                        f"REPO-CAT-{j+1:02d}", "REPO_CLASS", cat,
                        f"Category: {cat}. Description: {desc}.",
                        excel_row, [i for i in range(0,16) if val(row,i)],
                        extra={
                            "reason":         desc,
                            "impact":         "Architecture",
                            "truth_status":   "STABLE",
                            "related_layers": [cat],
                            "tags":           ["repo","category","architecture"],
                            "description":    desc,
                        }
                    ))

    # P1 strategic repos
    for (excel_row, row) in rows:
        if val(row,0) == "OpenWA" and "Communication" in val(row,1):
            seen_names = set()
            for i in range(0, 12, 2):
                name = val(row, i)
                role = val(row, i+1)
                if name and role and name not in seen_names:
                    seen_names.add(name)
                    records.append(make_record(
                        f"REPO-P1-{len(seen_names):03d}", "REPO_STRATEGIC", name,
                        f"Strategic repo: {name}. Role: {role}.",
                        excel_row, [i, i+1],
                        extra={
                            "reason":         role,
                            "impact":         "High",
                            "truth_status":   "ACTIVE",
                            "related_layers": [role],
                            "tags":           ["repo","p1","strategic"],
                            "strategic_role": role,
                        }
                    ))
            break

    return records


def extract_rh_log(rows):
    records = []
    in_log = False
    for (excel_row, row) in rows:
        if val(row, 0) == "RECRUITMENT HUB IMPLEMENTATION LOG":
            in_log = True
            continue
        if not in_log:
            continue
        if val(row, 0) == "Implementation ID":
            continue

        impl_id = val(row, 0)
        if not (impl_id.startswith("RH-") or impl_id.startswith("OMG-")):
            if impl_id in ("Priority","Status","Blockers","Next Action",""):
                continue
            if in_log and impl_id:
                in_log = False
            continue

        # OMG row is laid out differently
        if impl_id.startswith("OMG-"):
            hub    = val(row,2)
            feat   = f"{val(row,3)} / {val(row,4)}"
            status = val(row,6)
            build  = val(row,17)
            db_chg = val(row,18)
            git_st = val(row,19)
            risk   = val(row,20)
            nxt    = val(row,21)
        else:
            hub    = val(row,2)
            feat   = val(row,3)
            status = val(row,4)
            build  = val(row,9)
            db_chg = val(row,10)
            git_st = val(row,11)
            risk   = val(row,12)
            nxt    = val(row,13)

        content = (f"Implementation: {impl_id}. Hub: {hub}. Feature: {feat}. "
                   f"Status: {status}. Build: {build}. DB Change: {db_chg}. "
                   f"Git: {git_st}. Risk: {risk}. Next: {nxt}.")
        r = make_record(
            impl_id, "RH_LOG", f"{hub} — {feat}", content,
            excel_row, list(row.keys()),
            extra={
                "reason":         feat,
                "impact":         risk,
                "truth_status":   status,
                "related_layers": [hub] if hub else [],
                "tags":           ["implementation","log","git",
                                   hub.lower().replace(" ","-")],
                "build":          build,
                "db_change":      db_chg,
                "git_state":      git_st,
                "next_action":    nxt,
            }
        )
        records.append(r)

    return records


def extract_cv_rules(rows):
    PREFIX_MAP = {
        "SOURCE TRUTH:": ("CVR-SOURCE",   "SOURCE_TRUTH", "SOURCE TRUTH Rule"),
        "DERIVED TRUTH:":("CVR-DERIVED",  "DERIVED_TRUTH","DERIVED TRUTH Rule"),
        "UI PROJECTION:":("CVR-UI",       "UI_PROJECTION","UI PROJECTION Rule"),
        "FORBIDDEN:":    ("CVR-FORBIDDEN","FORBIDDEN",    "CV Cover FORBIDDEN Rule"),
        "FALLBACK RULE:":("CVR-FALLBACK", "FALLBACK",     "CV Cover FALLBACK Rule"),
        "PIPELINE RULE:":("CVR-PIPELINE", "PIPELINE",     "CV Cover PIPELINE Rule"),
        "FUTURE RULE:":  ("CVR-FUTURE",   "FUTURE",       "CV Cover FUTURE Rule"),
    }
    records = []
    seen = set()
    for (excel_row, row) in rows:
        text = val(row, 0)
        for prefix, (rid, rtype, rtitle) in PREFIX_MAP.items():
            if text.startswith(prefix) and rid not in seen:
                # Collect all cells on this row as rule text
                full_text = " ".join(str(row[k]) for k in sorted(row.keys()) if row[k])
                r = make_record(
                    rid, "CV_RULE", rtitle, full_text,
                    excel_row, list(row.keys()),
                    extra={
                        "reason":         "Recruitment CV Cover data integrity",
                        "impact":         "High",
                        "truth_status":   rtype,
                        "related_layers": ["Recruitment", "Call Center"],
                        "tags":           ["cv","rule","recruitment",rtype.lower()],
                        "rule_text":      full_text,
                    }
                )
                seen.add(rid)
                records.append(r)
                break
    return records


def extract_status(rows):
    STATUS_KEYS = {"Priority", "Status", "Blockers", "Next Action"}
    records = []
    seen = set()
    for (excel_row, row) in rows:
        label = val(row, 0)
        if label not in STATUS_KEYS or label in seen:
            continue
        # Collect all non-empty cells as content
        parts = [str(row[k]) for k in sorted(row.keys()) if row[k] and not str(row[k]).startswith("=")]
        content = " | ".join(parts)
        sid = f"STATUS-{label.upper().replace(' ','-')}"
        r = make_record(
            sid, "STATUS", f"NEXUS Current {label}", content,
            excel_row, list(row.keys()),
            extra={
                "reason":         f"Operational state tracking — {label}",
                "impact":         "Operational",
                "truth_status":   "ACTIVE",
                "related_layers": ["All Modules"],
                "tags":           ["status","nexus","current",label.lower().replace(" ","-")],
            }
        )
        seen.add(label)
        records.append(r)
    return records


def extract_stages(rows):
    """Decision Progression Stages."""
    records = []
    stage_info = {
        "Stage 1": ("Observability",              "STABLE"),
        "Stage 2": ("Recommendations",            "CURRENT / ACTIVE"),
        "Stage 3": ("Approval-Based Commands",    "PLANNING"),
        "Stage 4": ("Limited Autonomous Execution","FUTURE / RESEARCH"),
        "Stage 5": ("Adaptive Runtime Intelligence","HYPOTHESIS"),
    }
    seen = set()
    for (excel_row, row) in rows:
        for cidx, v in row.items():
            if str(v) in stage_info and str(v) not in seen:
                stage = str(v)
                mode, status = stage_info[stage]
                # Look for status in adjacent cells
                adj_status = val(row, cidx+1) or val(row, cidx+2) or status
                sid = f"STAGE-{stage[-1]}"
                content = f"{stage}: {mode}. Status: {adj_status}."
                r = make_record(
                    sid, "STAGE", f"{stage}: {mode}", content,
                    excel_row, [cidx, cidx+1, cidx+2],
                    extra={
                        "reason":         f"AI autonomy progression framework",
                        "impact":         "Global Governance",
                        "truth_status":   "ACTIVE" if "ACTIVE" in status else "PLANNING",
                        "related_layers": ["Decision Engine", "Governance"],
                        "tags":           ["stage","progression","autonomy",
                                           status.lower().split("/")[0].strip()],
                        "mode":           mode,
                        "current_status": adj_status,
                    }
                )
                seen.add(stage)
                records.append(r)
    records.sort(key=lambda x: x["id"])
    return records


# ─────────────────────────────────────────────
# DEDUP & VALIDATE
# ─────────────────────────────────────────────

def dedup_and_validate(all_records):
    seen_ids = {}
    deduped  = []
    anomalies = []

    for r in all_records:
        rid = r["id"]
        if rid in seen_ids:
            anomalies.append({
                "excel_row": r["source_row"],
                "issue": f"Duplicate record ID '{rid}' — already collected from row {seen_ids[rid]}",
                "action": "Skipped duplicate",
            })
        else:
            seen_ids[rid] = r["source_row"]
            deduped.append(r)

    # Check for near-duplicate content
    content_map = defaultdict(list)
    for r in deduped:
        key = r["content"][:80]
        content_map[key].append(r["id"])
    for key, ids in content_map.items():
        if len(ids) > 1:
            anomalies.append({
                "issue": f"Near-duplicate content in records: {ids}",
                "action": "Kept all; reported for review",
            })

    return deduped, anomalies


# ─────────────────────────────────────────────
# WRITE JSON
# ─────────────────────────────────────────────

def write_json(records, anomalies):
    type_counts = defaultdict(int)
    for r in records:
        type_counts[r["type"]] += 1

    index = {
        "meta": {
            "source_file":    SOURCE_FILE,
            "source_sheet":   SHEET_NAME,
            "generated_at":   datetime.now().isoformat(),
            "total_records":  len(records),
            "record_types":   dict(sorted(type_counts.items())),
            "anomaly_count":  len(anomalies),
        },
        "anomalies": anomalies,
        "records":   records,
    }
    with open(JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(index, f, ensure_ascii=False, indent=2)
    print(f"  ✓ JSON written → {JSON_PATH}  ({len(records)} records, {len(anomalies)} anomalies)")


# ─────────────────────────────────────────────
# WRITE SQLITE + FTS5
# ─────────────────────────────────────────────

def write_sqlite(records):
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)

    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()

    cur.execute("""
        CREATE TABLE nexus_md_records (
            rowid             INTEGER PRIMARY KEY AUTOINCREMENT,
            id                TEXT UNIQUE NOT NULL,
            type              TEXT NOT NULL,
            title             TEXT,
            content           TEXT,
            reason            TEXT,
            impact            TEXT,
            truth_status      TEXT,
            related_layers    TEXT,
            tags              TEXT,
            source_file       TEXT,
            source_sheet      TEXT,
            source_row        INTEGER,
            source_columns    TEXT,
            created_or_updated_at TEXT,
            json_data         TEXT
        )
    """)

    cur.execute("""
        CREATE VIRTUAL TABLE nexus_md_records_fts USING fts5(
            id,
            type,
            title,
            content,
            reason,
            impact,
            related_layers,
            tags,
            content='nexus_md_records',
            content_rowid='rowid'
        )
    """)

    for r in records:
        cur.execute("""
            INSERT INTO nexus_md_records
              (id, type, title, content, reason, impact, truth_status,
               related_layers, tags, source_file, source_sheet, source_row,
               source_columns, created_or_updated_at, json_data)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            r["id"],
            r["type"],
            r["title"],
            r["content"],
            r["reason"],
            r["impact"],
            r["truth_status"],
            json.dumps(r["related_layers"], ensure_ascii=False),
            " ".join(r["tags"]),
            r["source_file"],
            r["source_sheet"],
            r["source_row"],
            json.dumps(r["source_columns"]),
            r["created_or_updated_at"],
            json.dumps(r, ensure_ascii=False),
        ))

    cur.execute("""
        INSERT INTO nexus_md_records_fts
          (rowid, id, type, title, content, reason, impact, related_layers, tags)
        SELECT rowid, id, type, title, content, reason, impact, related_layers, tags
        FROM nexus_md_records
    """)

    # Stats view
    cur.execute("""
        CREATE VIEW nexus_md_stats AS
        SELECT type, COUNT(*) as count
        FROM nexus_md_records
        GROUP BY type ORDER BY count DESC
    """)

    con.commit()
    con.close()
    print(f"  ✓ SQLite written → {DB_PATH}")


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

def run():
    print(f"\n{'─'*55}")
    print(f"  NEXUS MD Importer — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'─'*55}")
    print(f"  Source: {XL_PATH} / Sheet: {SHEET_NAME}")
    print()

    print("  Loading sheet...")
    rows, xl_anomalies = load_sheet(XL_PATH, SHEET_NAME)
    print(f"  {len(rows)} non-empty rows, {len(xl_anomalies)} Excel-level anomalies")
    print()

    all_records = []
    all_anomalies = list(xl_anomalies)

    extractors = [
        ("ARCH",        extract_arch),
        ("DEC",         extract_dec),
        ("DAM",         extract_dam),
        ("TRUTH_TYPE",  extract_truth_types),
        ("SIGNAL",      extract_signals),
        ("FORBIDDEN",   extract_forbidden),
        ("REPO",        extract_repo),
        ("RH_LOG",      extract_rh_log),
        ("CV_RULE",     extract_cv_rules),
        ("STATUS",      extract_status),
        ("STAGE",       extract_stages),
    ]

    for label, fn in extractors:
        try:
            result = fn(rows)
            if isinstance(result, tuple):
                recs, anoms = result
                all_anomalies.extend(anoms)
            else:
                recs = result
            print(f"  [{label:<12}]  {len(recs):>3} records")
            all_records.extend(recs)
        except Exception as e:
            print(f"  [{label:<12}]  ERROR: {e}")
            all_anomalies.append({"issue": f"Extractor {label} failed: {e}"})

    print()
    all_records, dedup_anoms = dedup_and_validate(all_records)
    all_anomalies.extend(dedup_anoms)
    print(f"  Total after dedup: {len(all_records)} records, {len(all_anomalies)} anomalies")
    print()

    print("  Writing outputs...")
    write_json(all_records, all_anomalies)
    write_sqlite(all_records)

    # Summary by type
    type_counts = defaultdict(int)
    for r in all_records:
        type_counts[r["type"]] += 1

    print()
    print(f"{'─'*55}")
    print("  RECORD COUNT BY TYPE")
    print(f"{'─'*55}")
    total = 0
    for t in ["ARCH","DEC","DAM","SIGNAL","TRUTH_TYPE","FORBIDDEN",
              "REPO_CLASS","REPO_STRATEGIC","RH_LOG","CV_RULE","STATUS","STAGE"]:
        c = type_counts.get(t, 0)
        if c:
            print(f"  {t:<20} {c:>3}")
            total += c
    # any leftover types
    for t, c in sorted(type_counts.items()):
        if t not in ["ARCH","DEC","DAM","SIGNAL","TRUTH_TYPE","FORBIDDEN",
                     "REPO_CLASS","REPO_STRATEGIC","RH_LOG","CV_RULE","STATUS","STAGE"]:
            print(f"  {t:<20} {c:>3}")
            total += c
    print(f"{'─'*55}")
    print(f"  {'TOTAL':<20} {total:>3}")
    print(f"{'─'*55}")

    if all_anomalies:
        print(f"\n  ANOMALIES DETECTED ({len(all_anomalies)})")
        print(f"{'─'*55}")
        for a in all_anomalies[:20]:
            row_ref = f"  Row {a['excel_row']}:" if a.get("excel_row") else " "
            print(f"{row_ref} {a.get('issue','?')[:90]}")
            if a.get("action"):
                print(f"           → {a['action']}")
        if len(all_anomalies) > 20:
            print(f"  ... ({len(all_anomalies)-20} more — see JSON anomalies array)")

    print(f"\n  ✓ Done.\n")
    return all_records, all_anomalies


if __name__ == "__main__":
    run()
