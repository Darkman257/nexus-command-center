#!/usr/bin/env python3
"""
NEXUS Capability Registry
Read, search, filter, and display NEXUS capabilities.
Reads from nexus_capabilities.json and nexus_capabilities.sqlite (if built).

Usage:
    python capability_registry.py                          # list all
    python capability_registry.py --domain Fleet           # filter by domain
    python capability_registry.py --maturity STABLE        # filter by maturity
    python capability_registry.py --search "factory fleet" # full-text search
    python capability_registry.py --id CAP-FLEET-001       # single capability
    python capability_registry.py --stats                  # domain stats
    python capability_registry.py --pending                # pending patches
    python capability_registry.py --reusable-for Factory   # by sector
    python capability_registry.py --json                   # output as JSON
"""

import json
import argparse
import sqlite3
import os
import sys
from datetime import datetime

# ── paths ──────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
JSON_FILE = os.path.join(BASE_DIR, "nexus_capabilities.json")
DB_FILE = os.path.join(BASE_DIR, "nexus_capabilities.sqlite")
SCHEMA_FILE = os.path.join(BASE_DIR, "nexus_capability_schema.sql")

# ── ANSI colors ────────────────────────────────────────────────────────
R = "\033[0m"
BOLD = "\033[1m"
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
MAGENTA = "\033[95m"
RED = "\033[91m"
DIM = "\033[2m"

MATURITY_COLORS = {
    "IDEA": DIM,
    "DRAFT": YELLOW,
    "PILOT": CYAN,
    "STABLE": GREEN,
    "REUSABLE_TEMPLATE": MAGENTA,
    "CORE_CAPABILITY": f"{BOLD}{GREEN}",
    "DEPRECATED": RED,
}

APPROVAL_COLORS = {
    "APPROVED": GREEN,
    "PENDING": YELLOW,
    "REJECTED": RED,
    "MERGED": CYAN,
}


# ── DB bootstrap ───────────────────────────────────────────────────────
def ensure_db():
    """Create SQLite DB from schema and seed from JSON if DB doesn't exist."""
    if os.path.exists(DB_FILE):
        return sqlite3.connect(DB_FILE)

    if not os.path.exists(SCHEMA_FILE):
        print(f"{RED}ERROR: Schema file not found: {SCHEMA_FILE}{R}")
        sys.exit(1)

    con = sqlite3.connect(DB_FILE)
    con.row_factory = sqlite3.Row

    with open(SCHEMA_FILE) as f:
        con.executescript(f.read())

    # Seed from JSON
    if os.path.exists(JSON_FILE):
        with open(JSON_FILE) as f:
            data = json.load(f)
        for cap in data.get("capabilities", []):
            _insert_capability(con, cap)
        for patch in data.get("pending_patches", []):
            _insert_patch(con, patch)
        con.commit()
        print(f"{GREEN}✅ DB created and seeded: {DB_FILE}{R}")
    return con


def _insert_capability(con, cap):
    fields = [
        "id", "name", "domain", "description", "source_project", "source_update",
        "maturity", "reusable_for", "required_data", "suggested_tables",
        "suggested_ui", "automation_opportunities", "risks", "guards",
        "related_arch", "related_decisions", "approval_status", "created_at", "updated_at"
    ]
    values = []
    for f in fields:
        v = cap.get(f, "")
        if isinstance(v, list):
            v = json.dumps(v, ensure_ascii=False)
        values.append(v or "")
    placeholders = ",".join(["?"] * len(fields))
    con.execute(
        f"INSERT OR REPLACE INTO nexus_capabilities ({','.join(fields)}) VALUES ({placeholders})",
        values
    )


def _insert_patch(con, patch):
    con.execute("""
        INSERT OR REPLACE INTO nexus_capability_patches
        (id, capability_id, patch_type, source_project, source_update_text,
         classification, proposed_data, diff_summary, status, reviewed_by,
         reviewed_at, notes, created_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        patch.get("id", ""), patch.get("capability_id"), patch.get("patch_type", "NEW"),
        patch.get("source_project", ""), patch.get("source_update_text", ""),
        patch.get("classification", ""), json.dumps(patch.get("proposed_data", {})),
        patch.get("diff_summary", ""), patch.get("status", "PENDING"),
        patch.get("reviewed_by"), patch.get("reviewed_at"), patch.get("notes"),
        patch.get("created_at", datetime.now().strftime("%Y-%m-%d"))
    ))


def get_db():
    con = ensure_db()
    con.row_factory = sqlite3.Row
    return con


# ── display helpers ────────────────────────────────────────────────────
def mat_color(m):
    return MATURITY_COLORS.get(m, R)


def appr_color(a):
    return APPROVAL_COLORS.get(a, R)


def parse_json_field(v):
    if not v:
        return []
    if isinstance(v, list):
        return v
    try:
        return json.loads(v)
    except Exception:
        return [v]


def print_capability(cap, verbose=False):
    cap = dict(cap)
    mc = mat_color(cap.get("maturity", ""))
    ac = appr_color(cap.get("approval_status", ""))

    print(f"\n{BOLD}{CYAN}{'─'*70}{R}")
    print(f"  {BOLD}{cap['id']}{R}  │  {mc}{cap.get('maturity','?')}{R}  │  {ac}{cap.get('approval_status','?')}{R}")
    print(f"  {BOLD}{cap['name']}{R}")
    print(f"  {DIM}Domain:{R} {cap.get('domain','')}  │  {DIM}Source:{R} {cap.get('source_project','')}")

    if cap.get("description"):
        print(f"  {DIM}Description:{R} {cap['description'][:120]}")

    reusable = parse_json_field(cap.get("reusable_for", ""))
    if reusable:
        print(f"  {DIM}Reusable for:{R} {', '.join(reusable)}")

    if verbose:
        for field, label in [
            ("required_data", "Required data"),
            ("suggested_tables", "Suggested tables"),
            ("suggested_ui", "Suggested UI"),
            ("automation_opportunities", "Automation"),
            ("risks", "Risks"),
            ("guards", "Guards"),
            ("related_arch", "Related ARCH"),
            ("related_decisions", "Related DEC"),
        ]:
            items = parse_json_field(cap.get(field, ""))
            if items:
                print(f"  {DIM}{label}:{R} {', '.join(items)}")

        print(f"  {DIM}Created:{R} {cap.get('created_at','')}  │  {DIM}Updated:{R} {cap.get('updated_at','')}")


def print_stats(con):
    print(f"\n{BOLD}{'═'*60}{R}")
    print(f"{BOLD}  NEXUS Capability Registry — Stats{R}")
    print(f"{'═'*60}")

    rows = con.execute("SELECT * FROM capability_summary").fetchall()
    total = sum(r["total"] for r in rows)
    print(f"  {'Domain':<22} {'Total':>5} {'Core':>5} {'Stable':>7} {'Pilot':>6} {'Draft':>6} {'Pending':>8}")
    print(f"  {'─'*22} {'─'*5} {'─'*5} {'─'*7} {'─'*6} {'─'*6} {'─'*8}")
    for r in rows:
        print(f"  {r['domain']:<22} {r['total']:>5} {r['core_count']:>5} {r['stable_count']:>7} {r['pilot_count']:>6} {r['draft_count']:>6} {r['pending_approval']:>8}")
    print(f"  {'─'*22} {'─'*5}")
    print(f"  {'TOTAL':<22} {total:>5}")

    # Maturity breakdown
    print(f"\n  {'Maturity':<22} Count")
    print(f"  {'─'*22} ─────")
    mat_rows = con.execute(
        "SELECT maturity, COUNT(*) as cnt FROM nexus_capabilities GROUP BY maturity ORDER BY cnt DESC"
    ).fetchall()
    for r in mat_rows:
        mc = mat_color(r["maturity"])
        print(f"  {mc}{r['maturity']:<22}{R} {r['cnt']:>5}")
    print()


# ── search ─────────────────────────────────────────────────────────────
def search_capabilities(con, query, domain=None, maturity=None,
                        reusable_for=None, limit=20):
    results = []
    # Direct ID lookup
    if query and query.upper().startswith("CAP-"):
        row = con.execute(
            "SELECT * FROM nexus_capabilities WHERE UPPER(id) = ?", (query.upper(),)
        ).fetchone()
        if row:
            return [row]

    # FTS5 search
    if query:
        words = [w for w in query.split() if len(w) >= 2]
        fts_q = " OR ".join(words) if words else query
        try:
            rows = con.execute("""
                SELECT c.*, bm25(nexus_capabilities_fts) as score
                FROM nexus_capabilities_fts
                JOIN nexus_capabilities c ON c.rowid = nexus_capabilities_fts.rowid
                WHERE nexus_capabilities_fts MATCH ?
                ORDER BY score LIMIT ?
            """, (fts_q, limit * 3)).fetchall()
            results = list(rows)
        except sqlite3.OperationalError:
            # LIKE fallback
            like = f"%{query}%"
            results = con.execute("""
                SELECT * FROM nexus_capabilities
                WHERE name LIKE ? OR description LIKE ? OR domain LIKE ? OR reusable_for LIKE ?
                LIMIT ?
            """, (like, like, like, like, limit)).fetchall()
    else:
        results = con.execute("SELECT * FROM nexus_capabilities").fetchall()

    # Post-filter
    filtered = []
    for r in results:
        r = dict(r)
        if domain and r.get("domain", "").lower() != domain.lower():
            continue
        if maturity and r.get("maturity", "").upper() != maturity.upper():
            continue
        if reusable_for:
            rf = parse_json_field(r.get("reusable_for", ""))
            if not any(reusable_for.lower() in x.lower() for x in rf):
                continue
        filtered.append(r)

    return filtered[:limit]


# ── main ───────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="NEXUS Capability Registry")
    parser.add_argument("--domain", help="Filter by domain (Fleet, Recruitment, ...)")
    parser.add_argument("--maturity", help="Filter by maturity level")
    parser.add_argument("--search", help="Full-text search query")
    parser.add_argument("--id", help="Show single capability by ID")
    parser.add_argument("--reusable-for", dest="reusable_for", help="Filter by sector (Factory, Construction, ...)")
    parser.add_argument("--stats", action="store_true", help="Show domain statistics")
    parser.add_argument("--pending", action="store_true", help="Show pending patches")
    parser.add_argument("--verbose", action="store_true", help="Show full details")
    parser.add_argument("--json", dest="as_json", action="store_true", help="Output as JSON")
    parser.add_argument("--limit", type=int, default=20)
    args = parser.parse_args()

    con = get_db()

    if args.stats:
        print_stats(con)
        return

    if args.pending:
        patches = con.execute(
            "SELECT * FROM nexus_capability_patches WHERE status='PENDING' ORDER BY created_at DESC"
        ).fetchall()
        if not patches:
            print(f"\n{GREEN}✅ No pending patches.{R}\n")
        else:
            print(f"\n{YELLOW}{BOLD}⚠  Pending Capability Patches: {len(patches)}{R}\n")
            for p in patches:
                print(f"  {BOLD}{p['id']}{R}  [{p['patch_type']}]  {p['source_update_text'][:80]}")
                print(f"    Classification: {p['classification']}  │  Project: {p['source_project']}")
                print(f"    Created: {p['created_at']}\n")
        return

    if args.id:
        row = con.execute(
            "SELECT * FROM nexus_capabilities WHERE UPPER(id)=?", (args.id.upper(),)
        ).fetchone()
        if not row:
            print(f"{RED}Not found: {args.id}{R}")
            return
        if args.as_json:
            print(json.dumps(dict(row), ensure_ascii=False, indent=2))
            return
        print_capability(row, verbose=True)
        return

    query = args.search or ""
    results = search_capabilities(
        con, query,
        domain=args.domain,
        maturity=args.maturity,
        reusable_for=args.reusable_for,
        limit=args.limit
    )

    if args.as_json:
        print(json.dumps([dict(r) for r in results], ensure_ascii=False, indent=2))
        return

    if not results:
        print(f"\n{YELLOW}No capabilities found.{R}\n")
        return

    label = f"NEXUS Capability Registry"
    if query:
        label += f" — search: '{query}'"
    if args.domain:
        label += f" — domain: {args.domain}"
    if args.maturity:
        label += f" — maturity: {args.maturity}"
    if args.reusable_for:
        label += f" — sector: {args.reusable_for}"

    print(f"\n{BOLD}{'═'*70}{R}")
    print(f"{BOLD}  {label}{R}")
    print(f"{BOLD}  {len(results)} result(s){R}")
    print(f"{'═'*70}")

    for r in results:
        print_capability(r, verbose=args.verbose)

    print(f"\n{DIM}Run with --verbose for full details │ --stats for summary │ --pending for patches{R}\n")
    con.close()


if __name__ == "__main__":
    main()
