-- ============================================================
-- NEXUS Capability Engine — SQLite Schema
-- Version: 1.0
-- Date: 2026-05-22
-- ============================================================

-- ============================================================
-- TABLE: nexus_capabilities
-- Master registry of all NEXUS reusable capabilities
-- ============================================================
CREATE TABLE IF NOT EXISTS nexus_capabilities (
    id                      TEXT PRIMARY KEY,               -- e.g. CAP-FLEET-001
    name                    TEXT NOT NULL,
    domain                  TEXT NOT NULL,                  -- Fleet, Recruitment, Governance, etc.
    description             TEXT,
    source_project          TEXT,                           -- Omega, NEXUS Core, etc.
    source_update           TEXT,                           -- free text: what triggered this cap
    maturity                TEXT NOT NULL DEFAULT 'DRAFT',  -- IDEA|DRAFT|PILOT|STABLE|REUSABLE_TEMPLATE|CORE_CAPABILITY|DEPRECATED
    reusable_for            TEXT,                           -- JSON array: ["Construction","Factory",...]
    required_data           TEXT,                           -- JSON array of field names
    suggested_tables        TEXT,                           -- JSON array of table names
    suggested_ui            TEXT,                           -- JSON array of component names
    automation_opportunities TEXT,                         -- JSON array
    risks                   TEXT,                           -- JSON array
    guards                  TEXT,                           -- JSON array of guard rules
    related_arch            TEXT,                           -- JSON array: ["ARCH-017","ARCH-025"]
    related_decisions       TEXT,                           -- JSON array: ["DEC-001","DEC-007"]
    approval_status         TEXT NOT NULL DEFAULT 'PENDING', -- PENDING|APPROVED|REJECTED|MERGED
    created_at              TEXT NOT NULL,
    updated_at              TEXT NOT NULL
);

-- ============================================================
-- TABLE: nexus_capability_patches
-- Pending changes to capabilities waiting for Human Approval
-- No capability is modified without an approved patch.
-- ============================================================
CREATE TABLE IF NOT EXISTS nexus_capability_patches (
    id                  TEXT PRIMARY KEY,           -- PATCH-2026-001 etc.
    capability_id       TEXT,                       -- NULL if new capability
    patch_type          TEXT NOT NULL,              -- NEW|UPDATE|MERGE|DEPRECATE
    source_project      TEXT,
    source_update_text  TEXT NOT NULL,              -- raw input that triggered this patch
    classification      TEXT NOT NULL,              -- classification type (9 types)
    proposed_data       TEXT NOT NULL,              -- JSON: full proposed capability data
    diff_summary        TEXT,                       -- human-readable diff vs existing
    status              TEXT NOT NULL DEFAULT 'PENDING', -- PENDING|APPROVED|REJECTED
    reviewed_by         TEXT,                       -- who approved/rejected
    reviewed_at         TEXT,
    notes               TEXT,
    created_at          TEXT NOT NULL,
    FOREIGN KEY (capability_id) REFERENCES nexus_capabilities(id)
);

-- ============================================================
-- TABLE: nexus_learning_sessions
-- Records each project update ingested for audit trail
-- ============================================================
CREATE TABLE IF NOT EXISTS nexus_learning_sessions (
    id              TEXT PRIMARY KEY,
    project         TEXT NOT NULL,              -- Omega, NewClient, etc.
    raw_input       TEXT NOT NULL,              -- original text of the update
    classification  TEXT NOT NULL,              -- output classification
    action_taken    TEXT NOT NULL,              -- CREATED_PATCH|STORED_CLIENT_PACK|NO_ACTION|etc.
    patch_id        TEXT,                       -- link to patch if created
    created_at      TEXT NOT NULL,
    FOREIGN KEY (patch_id) REFERENCES nexus_capability_patches(id)
);

-- ============================================================
-- TABLE: nexus_capability_promotions
-- Immutable log of every capability promotion to Core
-- ============================================================
CREATE TABLE IF NOT EXISTS nexus_capability_promotions (
    id              TEXT PRIMARY KEY,
    capability_id   TEXT NOT NULL,
    from_maturity   TEXT NOT NULL,
    to_maturity     TEXT NOT NULL,
    patch_id        TEXT NOT NULL,
    promoted_by     TEXT NOT NULL DEFAULT 'human',
    promoted_at     TEXT NOT NULL,
    notes           TEXT,
    FOREIGN KEY (capability_id) REFERENCES nexus_capabilities(id),
    FOREIGN KEY (patch_id) REFERENCES nexus_capability_patches(id)
);

-- ============================================================
-- FTS5 VIRTUAL TABLE: nexus_capabilities_fts
-- Full-text search over capability registry
-- ============================================================
CREATE VIRTUAL TABLE IF NOT EXISTS nexus_capabilities_fts
USING fts5(
    id,
    name,
    domain,
    description,
    source_project,
    reusable_for,
    required_data,
    suggested_tables,
    risks,
    guards,
    related_arch,
    related_decisions,
    content='nexus_capabilities',
    content_rowid='rowid'
);

-- ============================================================
-- TRIGGER: sync FTS on insert
-- ============================================================
CREATE TRIGGER IF NOT EXISTS cap_ai AFTER INSERT ON nexus_capabilities BEGIN
    INSERT INTO nexus_capabilities_fts(rowid, id, name, domain, description, source_project,
        reusable_for, required_data, suggested_tables, risks, guards, related_arch, related_decisions)
    VALUES (new.rowid, new.id, new.name, new.domain, new.description, new.source_project,
        new.reusable_for, new.required_data, new.suggested_tables, new.risks, new.guards,
        new.related_arch, new.related_decisions);
END;

-- ============================================================
-- TRIGGER: sync FTS on update
-- ============================================================
CREATE TRIGGER IF NOT EXISTS cap_au AFTER UPDATE ON nexus_capabilities BEGIN
    INSERT INTO nexus_capabilities_fts(nexus_capabilities_fts, rowid, id, name, domain, description,
        source_project, reusable_for, required_data, suggested_tables, risks, guards, related_arch,
        related_decisions)
    VALUES ('delete', old.rowid, old.id, old.name, old.domain, old.description, old.source_project,
        old.reusable_for, old.required_data, old.suggested_tables, old.risks, old.guards,
        old.related_arch, old.related_decisions);
    INSERT INTO nexus_capabilities_fts(rowid, id, name, domain, description, source_project,
        reusable_for, required_data, suggested_tables, risks, guards, related_arch, related_decisions)
    VALUES (new.rowid, new.id, new.name, new.domain, new.description, new.source_project,
        new.reusable_for, new.required_data, new.suggested_tables, new.risks, new.guards,
        new.related_arch, new.related_decisions);
END;

-- ============================================================
-- VIEW: capability_summary
-- ============================================================
CREATE VIEW IF NOT EXISTS capability_summary AS
SELECT
    domain,
    COUNT(*) as total,
    SUM(CASE WHEN maturity = 'CORE_CAPABILITY' THEN 1 ELSE 0 END) as core_count,
    SUM(CASE WHEN maturity = 'STABLE' THEN 1 ELSE 0 END) as stable_count,
    SUM(CASE WHEN maturity = 'PILOT' THEN 1 ELSE 0 END) as pilot_count,
    SUM(CASE WHEN maturity IN ('IDEA','DRAFT') THEN 1 ELSE 0 END) as draft_count,
    SUM(CASE WHEN approval_status = 'PENDING' THEN 1 ELSE 0 END) as pending_approval
FROM nexus_capabilities
GROUP BY domain
ORDER BY total DESC;
