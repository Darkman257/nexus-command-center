# NEXUS Commander — Capability Engine UI Specification

**Version:** 1.0
**Date:** 2026-05-22
**Status:** DRAFT — Ready for Frontend Implementation

---

## Overview

NEXUS Commander adds a new panel called **NEXUS Capability Engine**.
This panel is the operating brain of NEXUS — it shows what NEXUS can do, what it learned, and what needs human approval before going live.

This is **not a website**. This is a panel inside NEXUS Commander.

---

## 5 Command Center Modes

### Mode 1 — Ask NEXUS Memory

**Panel title:** `Ask NEXUS Memory`

**What it does:**
- Chat-style interface for querying NEXUS architecture decisions and rules
- Searches `nexus_md_search.sqlite` (FTS5)
- Shows: ID, title, type, content, source_row, related decisions

**Input:** Free text question
**Output:** Ranked results with source traceability

**Example queries:**
- "ما هو Human Approval Guard؟"
- "ما قرارات Entity Purity Law؟"
- "ARCH-025 يقول إيه؟"

**Backend:** `GET /api/nexus-memory/search?q=...`

---

### Mode 2 — Business Intake Advisor

**Panel title:** `Business Intake Advisor`

**What it does:**
- User types: "أنا في مصنع حلويات"
- NEXUS responds with a structured intake briefing

**Response structure:**
```
┌─────────────────────────────────────────────────────┐
│  Sector Detected: Food Production / Sweets Factory  │
├─────────────────────────────────────────────────────┤
│  Matching Capabilities (7)                          │
│  ✅ Attendance Parser         (STABLE)               │
│  ✅ Daily Manpower Report     (STABLE)               │
│  ✅ Duplicate Detection       (STABLE)               │
│  ✅ File Analyzer             (STABLE)               │
│  🟡 Inventory Management      (DRAFT)                │
│  🟡 Production Orders         (DRAFT)                │
│  🔴 Recipe/BOM Costing        (IDEA — not built)    │
├─────────────────────────────────────────────────────┤
│  Files to Request (9)                               │
│  • Products list                                    │
│  • Raw materials list                               │
│  • Recipes / BOM                                    │
│  • Daily production log                             │
│  • Inventory snapshot                               │
│  • Attendance / shifts                              │
│  • Sales & orders                                   │
│  • Returns / quality                                │
│  • Machine maintenance log                          │
├─────────────────────────────────────────────────────┤
│  First 30 Days Plan                                 │
│  Week 1-2: File Analyzer + field mapping            │
│  Week 2-3: Attendance + Manpower Report             │
│  Week 3-4: Inventory + Production                   │
│  Month 2:  Reporting + Alerts                       │
├─────────────────────────────────────────────────────┤
│  Reusable from Omega                                │
│  ✅ Attendance Parser, Manpower, Dedup, File Analyzer│
│  ❌ Fleet (no delivery), Accommodation (no on-site) │
└─────────────────────────────────────────────────────┘
```

**Backend:** `POST /api/nexus-business/intake`

---

### Mode 3 — Analyze Uploaded Company Files

**Panel title:** `Analyze Uploaded Files`

**What it does:**
- User uploads Excel/CSV
- NEXUS previews structure, detects anomalies, suggests field mapping
- **Preview only — no DB write**

**UI Elements:**
- `FileUploadZone` — drag/drop or browse
- `StructurePreviewTable` — column names, data types, sample values, non-empty %
- `AnomalyHighlighter` — marks formula cells, empty rows, duplicate IDs
- `FieldMappingSuggester` — suggests NEXUS field mapping based on column names
- `ApprovalBar` — "Write to DB" button (disabled until user confirms mapping)

**Preview shows:**
- Rows scanned / non-empty
- Columns detected
- Anomalies (formula cells, empty mandatory fields, suspected duplicates)
- Suggested NEXUS table mapping
- Fields with <50% fill rate (flagged)

**Guard:** No DB write happens from this mode. Preview only.

**Backend:** `POST /api/nexus-business/dna-preview`

---

### Mode 4 — Project Learning Intake

**Panel title:** `Project Learning Intake`

**What it does:**
- User types or pastes a project update
- NEXUS classifies it, creates Pending Patch if needed
- Shows result inline

**UI Elements:**
- `ProjectSelector` dropdown (Omega, NewProject, ...)
- `UpdateTextArea` — multi-line free text
- `ClassifyButton` — runs ingest
- `ClassificationBadge` — shows detected type with color
- `MatchedKeywordChips` — shows which keywords triggered classification
- `PatchPreviewCard` — shows proposed capability if patch created
- `ApprovalRequiredBanner` — always shown if patch created

**Result states:**
```
PROJECT_SPECIFIC     → 🟡 "Stored in [Project] Business Pack only"
REUSABLE_CAPABILITY  → 🟢 "Pending Patch created — needs approval"
CORE_RULE            → 🔵 "Core Rule patch created — needs ARCH review"
COMPLIANCE_GUARD     → 🔴 "Compliance Guard detected — fast-track review"
CLIENT_CONFIGURATION → 🟡 "Stored in client config — not promoted"
```

**Example interaction:**
```
User: "في أوميجا عملنا Fleet P1 للعربيات والصيانة"

NEXUS:
  Classification:     REUSABLE_CAPABILITY  ✓
  Domain:             Fleet
  Matched keywords:   fleet, عربيات, صيانة
  Reusable for:       Construction, Factory, Distribution
  Patch created:      PATCH-20260522-143201
  Status:             PENDING — awaiting human approval
```

**Backend:** `POST /api/nexus-learning/ingest`

---

### Mode 5 — Capability Registry

**Panel title:** `NEXUS Capability Registry`

**What it does:**
- Shows all NEXUS capabilities with full metadata
- Filterable by domain, maturity, sector, status
- Allows promote/deprecate from UI

**UI Elements:**
- `DomainFilterTabs` — All | Fleet | Recruitment | Attendance | Governance | ...
- `MaturityFilterDropdown` — All | PILOT | STABLE | CORE_CAPABILITY | ...
- `SectorSearchBox` — "can be used in Factory"
- `CapabilityGrid` — cards with: name, domain, maturity badge, approval status, source
- `CapabilityDetailDrawer` — opens on click, shows full metadata
- `PatchesPanel` — pending patches at bottom
- `PromoteButton` — visible only for APPROVED capabilities, triggers review flow

**Capability Card:**
```
┌─────────────────────────────────────────┐
│  CAP-FLEET-001                          │
│  Fleet Tracking P1            [PILOT]   │
│  Domain: Fleet                          │
│  Source: Omega  │  Approved ✅           │
│  Reusable: Construction, Factory, ...   │
│                          [View Details] │
└─────────────────────────────────────────┘
```

**Maturity colors:**
- IDEA → gray
- DRAFT → yellow
- PILOT → cyan
- STABLE → green
- REUSABLE_TEMPLATE → purple
- CORE_CAPABILITY → bold green
- DEPRECATED → red

**Backend:** `GET /api/nexus-capabilities` + `POST /api/nexus-capabilities/search`

---

## NEXUS Capability Engine Panel (Main Container)

```
┌──────────────────────────────────────────────────────────────────────┐
│  NEXUS Capability Engine                                    [⚙ Admin]│
├──────────────────┬───────────────────────────────────────────────────┤
│                  │                                                    │
│  📚 Ask Memory   │                                                    │
│  🏢 Business     │         [Main Content Area]                        │
│     Intake       │                                                    │
│  📄 File         │                                                    │
│     Analyzer     │                                                    │
│  📝 Project      │                                                    │
│     Learning     │                                                    │
│  🗂 Capability   │                                                    │
│     Registry     │                                                    │
│                  │                                                    │
├──────────────────┤                                                    │
│  ⚠ Pending (3)  │                                                    │
│  PATCH-001       │                                                    │
│  PATCH-002       │                                                    │
│  PATCH-003       │                                                    │
└──────────────────┴───────────────────────────────────────────────────┘
```

**Sidebar badges:**
- Pending patches count shown as badge on "Project Learning" and "Registry" items
- Red badge if any COMPLIANCE_GUARD patches pending

---

## Search Examples That Must Work

| Query | Expected Result |
|-------|----------------|
| `what capabilities do we have for factories?` | Fleet, Attendance, Recruitment, Manpower, Dedup, File Analyzer |
| `what did Omega teach NEXUS?` | All caps with source_project=Omega |
| `can Fleet P1 be reused in a sweets factory?` | CAP-FLEET-001 with reusable_for including Factory |
| `what modules should start first for a construction company?` | Business Intake result with 30-day plan |
| `what is stable and what is still pilot?` | Filtered list: STABLE vs PILOT maturity |
| `what should not be promoted to core?` | PROJECT_SPECIFIC + CLIENT_CONFIGURATION items |

---

## API Reference (when backend exists)

```
GET  /api/nexus-capabilities                          List all capabilities
POST /api/nexus-capabilities/search                   Search capabilities
     body: { query, domain, maturity, reusable_for }

POST /api/nexus-learning/ingest                       Classify project update
     body: { project, text }

POST /api/nexus-learning/create-capability-patch      Create patch manually
     body: { capability_id, proposed_data, source_project }

GET  /api/nexus-learning/patches                      List pending patches
POST /api/nexus-learning/patches/:id/approve          Approve patch
POST /api/nexus-learning/patches/:id/reject           Reject patch

POST /api/nexus-business/intake                       Business intake advisor
     body: { sector_description }

POST /api/nexus-business/dna-preview                  Analyze uploaded file
     body: multipart/form-data with file
```

---

## Technology Notes

- No separate website.
- Panel is embedded in NEXUS Commander.
- Backend reads `nexus_capabilities.sqlite` and `nexus_md_search.sqlite`.
- All writes go through patch + approval flow — never direct DB write from UI.
- FTS5 powers all search.
- ANSI color in CLI tools maps 1:1 to badge colors in UI.

---

## Guards Summary

| Operation | Guard | Bypass allowed? |
|-----------|-------|----------------|
| Any DB write | Human approval | No |
| Capability promotion to CORE | Explicit 'PROMOTE' confirmation | No |
| File preview to DB write | Manual confirmation + field mapping approval | No |
| Patch overwrite | Show diff first | No |
| Project-specific data to Core | Blocked by classification | No |
