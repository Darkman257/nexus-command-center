#!/usr/bin/env python3
"""
NEXUS Project Learning Ingest
Processes project updates, classifies them, and creates Pending Capability Patches.
This is Mode 4 of NEXUS Commander — Project Learning Intake.

Classification types:
  PROJECT_SPECIFIC       → stays in Client Business Pack only
  REUSABLE_CAPABILITY    → creates Pending Capability Patch
  CORE_RULE              → creates Pending Core Memory Patch
  CLIENT_CONFIGURATION   → stored in Client Pack
  BUSINESS_PLAYBOOK      → added to Business Intake knowledge base
  DATA_IMPORT_PATTERN    → capability in Data Intake layer
  UI_PATTERN             → UI Library candidate
  AUTOMATION_PATTERN     → Automation Library candidate
  COMPLIANCE_GUARD       → Core Guard Layer candidate

Usage:
    python project_learning_ingest.py --project Omega --text "عملنا Fleet P1 للعربيات"
    python project_learning_ingest.py --file samples.json
    python project_learning_ingest.py --interactive
    python project_learning_ingest.py --demo    # run 4 sample ingest scenarios
"""

import json
import argparse
import sqlite3
import os
import sys
import re
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_FILE = os.path.join(BASE_DIR, "nexus_capabilities.sqlite")
JSON_FILE = os.path.join(BASE_DIR, "nexus_capabilities.json")

R = "\033[0m"
BOLD = "\033[1m"
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
MAGENTA = "\033[95m"
RED = "\033[91m"
DIM = "\033[2m"


def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def today():
    return datetime.now().strftime("%Y-%m-%d")


def make_patch_id():
    return f"PATCH-{datetime.now().strftime('%Y%m%d-%H%M%S-%f')}"


def make_session_id():
    return f"SESSION-{datetime.now().strftime('%Y%m%d-%H%M%S-%f')}"


def get_db():
    if not os.path.exists(DB_FILE):
        print(f"{YELLOW}DB not found — building from JSON...{R}")
        # Bootstrap it
        import subprocess
        subprocess.run([sys.executable, "capability_registry.py", "--stats"], check=False)
    if not os.path.exists(DB_FILE):
        print(f"{RED}ERROR: Could not create DB. Run capability_registry.py first.{R}")
        sys.exit(1)
    con = sqlite3.connect(DB_FILE)
    con.row_factory = sqlite3.Row
    return con


# ── Classification Engine ──────────────────────────────────────────────
# Keyword-based classification rules.
# In a production system this would use an LLM or a trained classifier.
# Here we use deterministic keyword rules that match NEXUS domain vocabulary.

CLASSIFICATION_RULES = [
    # COMPLIANCE_GUARD — highest priority
    {
        "type": "COMPLIANCE_GUARD",
        "keywords": ["preview before", "قبل الكتابة", "يمنع", "guard", "compliance",
                     "forbidden", "ممنوع", "يجب مراجعة", "approval required",
                     "موافقة إجبارية", "human review", "مراجعة بشرية"],
        "description": "A rule that prevents unsafe or irreversible operations.",
    },
    # CORE_RULE — architecture/governance
    {
        "type": "CORE_RULE",
        "keywords": ["قاعدة أساسية", "core rule", "architecture decision", "قرار معماري",
                     "arch decision", "entity purity", "causality", "source truth",
                     "decision authority", "يجب دائماً", "must always", "never",
                     "لا يجوز أبداً", "invariant", "قانون"],
        "description": "A fundamental architectural or governance rule for NEXUS Core.",
    },
    # PROJECT_SPECIFIC — data unique to one project (checked early, beats import/ui rules)
    {
        "type": "PROJECT_SPECIFIC",
        "keywords": ["اسم الشقة", "apartment name", "villa name", "اسم العقار",
                     "specific names", "أسماء محددة", "أسماء شقق", "شقق أوميجا",
                     "our employees", "موظفينا", "our vehicles", "عربياتنا",
                     "our sites", "مواقعنا", "بيانات أوميجا", "omega data",
                     "أضفنا أسماء"],
        "description": "Data or configuration unique to a specific project/client.",
    },
    # CLIENT_CONFIGURATION
    {
        "type": "CLIENT_CONFIGURATION",
        "keywords": ["أوميجا فقط", "omega only", "specific to", "خاص بـ",
                     "client setting", "إعداد العميل", "this client", "هذا العميل",
                     "custom field", "حقل مخصص", "our config"],
        "description": "Configuration or settings specific to one client.",
    },
    # REUSABLE_CAPABILITY — checked before DATA_IMPORT_PATTERN so "Recruitment Import" wins
    {
        "type": "REUSABLE_CAPABILITY",
        "keywords": ["recruitment import", "fleet", "عربيات", "سيارات", "vehicles",
                     "recruitment", "توظيف", "attendance", "حضور", "غياب",
                     "accommodation", "إقامة", "شقق", "سكن", "maintenance", "صيانة",
                     "tracking", "تتبع", "report", "تقرير", "manpower",
                     "قوى عاملة", "candidate", "مرشح", "cv", "payroll",
                     "رواتب", "inventory", "مخزون", "production", "إنتاج",
                     "quality", "جودة", "sales", "مبيعات", "distribution",
                     "توزيع", "duplicate", "تكرار", "dedup"],
        "description": "A pattern reusable across multiple clients and industries.",
    },
    # DATA_IMPORT_PATTERN
    {
        "type": "DATA_IMPORT_PATTERN",
        "keywords": ["excel import", "csv import", "استيراد", "import", "رفع ملف",
                     "file upload", "field mapping", "تعيين الحقول", "data intake",
                     "parse", "parsing", "ingest"],
        "description": "A pattern for importing data from external files into NEXUS.",
    },
    # AUTOMATION_PATTERN
    {
        "type": "AUTOMATION_PATTERN",
        "keywords": ["تلقائي", "automatic", "scheduled", "job", "cron", "daily",
                     "يومي", "alert", "notification", "تنبيه", "trigger",
                     "auto-generate", "إنشاء تلقائي"],
        "description": "A repeatable automation flow or scheduled operation.",
    },
    # UI_PATTERN
    {
        "type": "UI_PATTERN",
        "keywords": ["واجهة", "ui", "dashboard", "screen", "card", "view",
                     "شاشة", "panel", "modal", "form", "نموذج", "table",
                     "grid", "جدول", "display", "عرض"],
        "description": "A reusable UI component or screen layout.",
    },
    # BUSINESS_PLAYBOOK
    {
        "type": "BUSINESS_PLAYBOOK",
        "keywords": ["sector", "industry", "قطاع", "صناعة", "مجال", "business type",
                     "نوع الأعمال", "30 day", "30 يوم", "onboarding", "playbook",
                     "خطة بداية", "how nexus enters", "كيف يدخل نكسس"],
        "description": "How NEXUS operates in a specific business sector.",
    },
]


def classify(text):
    """Classify update text. Returns (type, confidence, matched_keywords, description)."""
    text_lower = text.lower()
    for rule in CLASSIFICATION_RULES:
        matched = [kw for kw in rule["keywords"] if kw.lower() in text_lower]
        if matched:
            return rule["type"], "RULE_MATCH", matched, rule["description"]
    # Default fallback
    return "REUSABLE_CAPABILITY", "LOW_CONFIDENCE", [], "Classified as reusable by default."


def suggest_domain(text):
    """Infer domain from keywords."""
    domains = {
        "Fleet": ["fleet", "vehicle", "عربي", "سيارة", "maintenance", "صيانة", "fuel", "وقود", "trip", "رحلة", "driver", "سائق"],
        "Recruitment": ["recruit", "candidate", "cv", "توظيف", "مرشح", "سيرة ذاتية", "job", "وظيفة"],
        "Attendance": ["attendance", "حضور", "غياب", "biometric", "shift", "ورديات", "check-in"],
        "Accommodation": ["accommodation", "شقة", "سكن", "room", "غرفة", "occupancy", "إقامة"],
        "Reporting": ["report", "تقرير", "manpower", "قوى عاملة", "daily", "يومي", "summary", "ملخص"],
        "Data Quality": ["duplicate", "تكرار", "dedup", "data quality", "جودة البيانات", "anomaly"],
        "Governance": ["approval", "موافقة", "guard", "compliance", "audit", "مراجعة", "rule"],
        "Data Intake": ["import", "excel", "csv", "استيراد", "file", "ملف", "upload", "رفع"],
        "UI": ["ui", "dashboard", "واجهة", "screen", "شاشة", "view", "card"],
        "Automation": ["automation", "تلقائي", "scheduled", "cron", "alert", "تنبيه"],
        "Inventory": ["inventory", "مخزون", "stock", "warehouse", "مستودع"],
        "Production": ["production", "إنتاج", "recipe", "bom", "وصفة"],
        "Sales": ["sales", "مبيعات", "distribution", "توزيع", "order", "طلب"],
    }
    text_lower = text.lower()
    scores = {}
    for domain, keywords in domains.items():
        score = sum(1 for kw in keywords if kw.lower() in text_lower)
        if score:
            scores[domain] = score
    if scores:
        return max(scores, key=scores.get)
    return "General"


def suggest_reusable_for(domain):
    """Map domain to likely sectors."""
    mapping = {
        "Fleet": ["Construction", "Factory", "Distribution", "Services", "Agriculture"],
        "Recruitment": ["Construction", "Factory", "Distribution", "Services", "Healthcare", "Retail"],
        "Attendance": ["Construction", "Factory", "Distribution", "Retail", "Healthcare", "Services"],
        "Accommodation": ["Construction", "Factory", "Agriculture", "Mining"],
        "Reporting": ["Construction", "Factory", "Distribution", "Services", "Government"],
        "Data Quality": ["Construction", "Factory", "Distribution", "Services", "Healthcare", "Government"],
        "Governance": ["Any NEXUS deployment"],
        "Data Intake": ["Construction", "Factory", "Distribution", "Services", "Healthcare", "Retail"],
        "UI": ["Construction", "Factory", "Distribution", "Services"],
        "Automation": ["Construction", "Factory", "Distribution", "Services"],
        "Inventory": ["Factory", "Distribution", "Retail", "Healthcare"],
        "Production": ["Factory", "Food Production", "Pharmaceuticals"],
        "Sales": ["Distribution", "Retail", "Factory"],
        "General": ["Construction", "Factory", "Distribution", "Services"],
    }
    return mapping.get(domain, ["Construction", "Factory", "Services"])


def suggest_cap_id(domain, con):
    """Generate next CAP ID for domain."""
    prefix_map = {
        "Fleet": "FLEET",
        "Recruitment": "REC",
        "Attendance": "ATT",
        "Accommodation": "ACC",
        "Reporting": "RPT",
        "Data Quality": "DQ",
        "Governance": "GOV",
        "Data Intake": "DI",
        "UI": "UI",
        "Automation": "AUTO",
        "Inventory": "INV",
        "Production": "PROD",
        "Sales": "SALES",
        "General": "GEN",
    }
    prefix = prefix_map.get(domain, "CAP")
    existing = con.execute(
        "SELECT id FROM nexus_capabilities WHERE id LIKE ?",
        (f"CAP-{prefix}-%",)
    ).fetchall()
    n = len(existing) + 1
    return f"CAP-{prefix}-{n:03d}"


def find_similar_capability(text, domain, con):
    """Check for existing similar capabilities."""
    domain_caps = con.execute(
        "SELECT * FROM nexus_capabilities WHERE domain=?", (domain,)
    ).fetchall()
    if domain_caps:
        return domain_caps[0]  # simplistic: return first in same domain
    return None


# ── Ingest ─────────────────────────────────────────────────────────────
def ingest(project, text, con, silent=False):
    """
    Main ingest function.
    Returns dict with: session_id, classification, action, patch_id (or None)
    """
    classification, confidence, matched_keywords, cls_desc = classify(text)
    domain = suggest_domain(text)
    ts = now_str()
    session_id = make_session_id()

    if not silent:
        print(f"\n{BOLD}{'─'*70}{R}")
        print(f"{BOLD}  Project Learning Ingest{R}")
        print(f"  Project: {CYAN}{project}{R}")
        print(f"  Input: {text[:120]}")
        print(f"{'─'*70}")
        print(f"  Classification:  {BOLD}{classification}{R}  ({confidence})")
        if matched_keywords:
            print(f"  Matched keywords: {', '.join(matched_keywords[:5])}")
        print(f"  Inferred domain: {domain}")

    # Determine action based on classification
    if classification == "PROJECT_SPECIFIC":
        action = "STORED_CLIENT_PACK"
        if not silent:
            print(f"\n  {YELLOW}→ Stored in {project} Business Pack only. NOT promoted to Core.{R}")
            print(f"  {DIM}Reason: Data is specific to {project}. No capability created.{R}")

        # Log session
        con.execute("""
            INSERT INTO nexus_learning_sessions
            (id, project, raw_input, classification, action_taken, patch_id, created_at)
            VALUES (?,?,?,?,?,?,?)
        """, (session_id, project, text, classification, action, None, ts))
        con.commit()
        return {"session_id": session_id, "classification": classification,
                "action": action, "patch_id": None, "domain": domain}

    elif classification == "CLIENT_CONFIGURATION":
        action = "STORED_CLIENT_CONFIG"
        if not silent:
            print(f"\n  {YELLOW}→ Stored as {project} Client Configuration.{R}")
        con.execute("""
            INSERT INTO nexus_learning_sessions
            (id, project, raw_input, classification, action_taken, patch_id, created_at)
            VALUES (?,?,?,?,?,?,?)
        """, (session_id, project, text, classification, action, None, ts))
        con.commit()
        return {"session_id": session_id, "classification": classification,
                "action": action, "patch_id": None, "domain": domain}

    elif classification in ("REUSABLE_CAPABILITY", "DATA_IMPORT_PATTERN",
                            "UI_PATTERN", "AUTOMATION_PATTERN"):
        # Check for similar existing capability
        similar = find_similar_capability(text, domain, con)
        if similar:
            if not silent:
                print(f"\n  {CYAN}→ Similar capability found: {similar['id']} — {similar['name']}{R}")
                print(f"  {DIM}Suggesting MERGE instead of new capability.{R}")
            patch_type = "UPDATE"
            cap_id = similar["id"]
        else:
            patch_type = "NEW"
            cap_id = None

        # Build proposed capability
        cap_id_new = cap_id or suggest_cap_id(domain, con)
        reusable_for = suggest_reusable_for(domain)

        proposed = {
            "id": cap_id_new,
            "name": f"{domain} Capability — {project}",
            "domain": domain,
            "description": f"Extracted from {project}: {text[:200]}",
            "source_project": project,
            "source_update": text[:200],
            "maturity": "PILOT" if similar else "DRAFT",
            "reusable_for": reusable_for,
            "required_data": [],
            "suggested_tables": [],
            "suggested_ui": [],
            "automation_opportunities": [],
            "risks": [],
            "guards": [],
            "related_arch": [],
            "related_decisions": [],
            "approval_status": "PENDING",
            "created_at": today(),
            "updated_at": today(),
        }

        patch_id = make_patch_id()
        con.execute("""
            INSERT INTO nexus_capability_patches
            (id, capability_id, patch_type, source_project, source_update_text,
             classification, proposed_data, diff_summary, status, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?)
        """, (
            patch_id, cap_id, patch_type, project, text[:500],
            classification, json.dumps(proposed, ensure_ascii=False),
            f"New {domain} capability from {project} project.",
            "PENDING", ts
        ))

        action = f"CREATED_PATCH_{patch_type}"
        if not silent:
            print(f"\n  {GREEN}→ Pending Capability Patch created: {patch_id}{R}")
            print(f"  {DIM}Type: {patch_type} │ Proposed ID: {cap_id_new}{R}")
            print(f"  {YELLOW}⚠  Requires Human Approval before being applied.{R}")
            print(f"  {DIM}Run: python capability_promoter.py --approve {patch_id}{R}")

        con.execute("""
            INSERT INTO nexus_learning_sessions
            (id, project, raw_input, classification, action_taken, patch_id, created_at)
            VALUES (?,?,?,?,?,?,?)
        """, (session_id, project, text, classification, action, patch_id, ts))
        con.commit()
        return {"session_id": session_id, "classification": classification,
                "action": action, "patch_id": patch_id, "domain": domain,
                "proposed_id": cap_id_new}

    elif classification in ("CORE_RULE", "COMPLIANCE_GUARD", "BUSINESS_PLAYBOOK"):
        # Create a core memory patch (different from capability patch)
        patch_id = make_patch_id()
        proposed = {
            "classification": classification,
            "source_project": project,
            "text": text,
            "suggested_action": "Add to NEXUS Core Memory or Compliance Guards",
            "requires_arch_review": True,
        }
        con.execute("""
            INSERT INTO nexus_capability_patches
            (id, capability_id, patch_type, source_project, source_update_text,
             classification, proposed_data, diff_summary, status, created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?)
        """, (
            patch_id, None, "CORE_RULE_PATCH", project, text[:500],
            classification, json.dumps(proposed, ensure_ascii=False),
            f"Core rule / compliance guard from {project}.",
            "PENDING", ts
        ))
        action = "CREATED_CORE_PATCH"

        if not silent:
            print(f"\n  {MAGENTA}→ Core Rule / Compliance Guard detected.{R}")
            print(f"  {MAGENTA}  Pending Core Memory Patch created: {patch_id}{R}")
            print(f"  {DIM}This must be reviewed and linked to an ARCH decision.{R}")
            print(f"  {YELLOW}⚠  Requires Human Approval before entering NEXUS Core.{R}")

        con.execute("""
            INSERT INTO nexus_learning_sessions
            (id, project, raw_input, classification, action_taken, patch_id, created_at)
            VALUES (?,?,?,?,?,?,?)
        """, (session_id, project, text, classification, action, patch_id, ts))
        con.commit()
        return {"session_id": session_id, "classification": classification,
                "action": action, "patch_id": patch_id, "domain": domain}

    else:
        action = "NO_ACTION"
        con.execute("""
            INSERT INTO nexus_learning_sessions
            (id, project, raw_input, classification, action_taken, patch_id, created_at)
            VALUES (?,?,?,?,?,?,?)
        """, (session_id, project, text, classification, action, None, ts))
        con.commit()
        return {"session_id": session_id, "classification": classification,
                "action": action, "patch_id": None, "domain": domain}


# ── Demo scenarios ─────────────────────────────────────────────────────
DEMO_SAMPLES = [
    {
        "project": "Omega",
        "text": "في أوميجا عملنا Fleet P1 للعربيات والصيانة والوقود والرحلات",
        "expected_classification": "REUSABLE_CAPABILITY",
        "label": "Omega Fleet P1",
    },
    {
        "project": "Omega",
        "text": "عملنا Recruitment Import بيستورد ملفات Excel للمرشحين ويعمل deduplication قبل ما يكتب في الداتابيز",
        "expected_classification": "REUSABLE_CAPABILITY",
        "label": "Recruitment Import",
    },
    {
        "project": "Omega",
        "text": "في الحضور عندنا deduplication للسجلات اللي بتيجي من الجهاز البيومتري والـ Excel في نفس اليوم",
        "expected_classification": "REUSABLE_CAPABILITY",
        "label": "Attendance Dedup",
    },
    {
        "project": "Omega",
        "text": "أضفنا أسماء شقق أوميجا المحددة: شقة النيل، فيلا الجيزة، مجمع 6 أكتوبر",
        "expected_classification": "PROJECT_SPECIFIC",
        "label": "Accommodation Occupancy",
    },
]


def run_demo(con):
    print(f"\n{BOLD}{'═'*70}{R}")
    print(f"{BOLD}  NEXUS Project Learning Ingest — Demo Mode{R}")
    print(f"  Running {len(DEMO_SAMPLES)} sample scenarios")
    print(f"{'═'*70}")

    results = []
    for i, sample in enumerate(DEMO_SAMPLES, 1):
        print(f"\n{BOLD}[{i}/{len(DEMO_SAMPLES)}] {sample['label']}{R}")
        result = ingest(sample["project"], sample["text"], con)
        expected = sample["expected_classification"]
        got = result["classification"]
        match = got == expected
        status = f"{GREEN}✅ CORRECT{R}" if match else f"{YELLOW}⚠ GOT {got}, expected {expected}{R}"
        print(f"  Result: {status}")
        results.append({
            "label": sample["label"],
            "expected": expected,
            "got": got,
            "match": match,
            "action": result["action"],
            "patch_id": result.get("patch_id"),
            "domain": result.get("domain"),
        })

    # Summary
    print(f"\n{BOLD}{'═'*70}{R}")
    print(f"{BOLD}  Demo Summary{R}")
    print(f"{'═'*70}")
    print(f"  {'Scenario':<30} {'Expected':<22} {'Got':<22} {'Action'}")
    print(f"  {'─'*30} {'─'*22} {'─'*22} {'─'*20}")
    for r in results:
        match_icon = "✅" if r["match"] else "⚠"
        print(f"  {match_icon} {r['label']:<28} {r['expected']:<22} {r['got']:<22} {r['action']}")

    passed = sum(1 for r in results if r["match"])
    print(f"\n  {GREEN if passed == len(results) else YELLOW}{passed}/{len(results)} classifications correct.{R}")

    patches = [r for r in results if r["patch_id"]]
    project_specific = [r for r in results if r["got"] == "PROJECT_SPECIFIC"]
    core_rules = [r for r in results if r["got"] in ("CORE_RULE", "COMPLIANCE_GUARD")]

    print(f"\n  Distribution:")
    print(f"  Reusable Capabilities → Pending Patches: {len(patches)}")
    print(f"  Project-Specific (Client Pack only):      {len(project_specific)}")
    print(f"  Core Rules / Compliance Guards:           {len(core_rules)}")

    if patches:
        print(f"\n  Pending Patches created:")
        for r in patches:
            print(f"    {r['patch_id']}  │  {r['label']}  │  domain: {r['domain']}")
        print(f"\n  {YELLOW}To approve: python capability_promoter.py --approve <PATCH_ID>{R}")

    print()
    return results


# ── main ───────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="NEXUS Project Learning Ingest")
    parser.add_argument("--project", help="Project name (e.g. Omega)")
    parser.add_argument("--text", help="Update text to classify and ingest")
    parser.add_argument("--file", help="JSON file with list of {project, text} objects")
    parser.add_argument("--demo", action="store_true", help="Run 4 demo scenarios")
    parser.add_argument("--interactive", action="store_true", help="Interactive mode")
    parser.add_argument("--sessions", action="store_true", help="Show recent sessions")
    parser.add_argument("--json", dest="as_json", action="store_true")
    args = parser.parse_args()

    con = get_db()

    if args.demo:
        results = run_demo(con)
        if args.as_json:
            print(json.dumps(results, ensure_ascii=False, indent=2))
        con.close()
        return

    if args.sessions:
        rows = con.execute(
            "SELECT * FROM nexus_learning_sessions ORDER BY created_at DESC LIMIT 20"
        ).fetchall()
        for r in rows:
            print(f"  {r['id']}  [{r['project']}]  {r['classification']}  "
                  f"→ {r['action']}  {r['created_at'][:16]}")
            print(f"    {r['raw_input'][:80]}")
        con.close()
        return

    if args.file:
        with open(args.file) as f:
            samples = json.load(f)
        for s in samples:
            ingest(s["project"], s["text"], con)
        con.close()
        return

    if args.interactive:
        print(f"\n{BOLD}  NEXUS Project Learning Ingest — Interactive Mode{R}")
        print(f"  Type 'quit' to exit.\n")
        while True:
            project = input(f"{CYAN}Project name:{R} ").strip()
            if project.lower() == "quit":
                break
            text = input(f"{CYAN}Update text:{R} ").strip()
            if not text:
                continue
            ingest(project, text, con)
        con.close()
        return

    if args.project and args.text:
        result = ingest(args.project, args.text, con)
        if args.as_json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        con.close()
        return

    parser.print_help()
    con.close()


if __name__ == "__main__":
    main()
