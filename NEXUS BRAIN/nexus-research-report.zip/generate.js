const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, HeadingLevel, BorderStyle, WidthType,
  ShadingType, VerticalAlign, PageNumber, PageBreak, LevelFormat,
  ExternalHyperlink, TableOfContents
} = require('docx');
const fs = require('fs');

const CONTENT_WIDTH = 9360; // US Letter 1" margins
const COL = (n, total) => Math.floor(CONTENT_WIDTH * n / total);

// Colors
const DARK_NAVY = "0D1B2A";
const ACCENT_BLUE = "1A73E8";
const ACCENT_ORANGE = "E8710A";
const ACCENT_GREEN = "1E8B4C";
const ACCENT_RED = "C62828";
const LIGHT_BLUE_BG = "EAF2FB";
const LIGHT_ORANGE_BG = "FEF3E2";
const LIGHT_GREEN_BG = "E8F5E9";
const LIGHT_RED_BG = "FFEBEE";
const LIGHT_GRAY_BG = "F5F6F8";
const MID_GRAY = "BDBDBD";
const DARK_TEXT = "212121";
const MID_TEXT = "424242";
const SUBTLE_TEXT = "757575";

const border = (color = "CCCCCC") => ({ style: BorderStyle.SINGLE, size: 1, color });
const borders = (color = "CCCCCC") => ({ top: border(color), bottom: border(color), left: border(color), right: border(color) });
const noBorder = () => ({ style: BorderStyle.NONE, size: 0, color: "FFFFFF" });
const noBorders = () => ({ top: noBorder(), bottom: noBorder(), left: noBorder(), right: noBorder() });

function cell(children, opts = {}) {
  return new TableCell({
    borders: opts.borders || borders(opts.borderColor || "CCCCCC"),
    width: { size: opts.width || COL(1, 1), type: WidthType.DXA },
    shading: opts.bg ? { fill: opts.bg, type: ShadingType.CLEAR } : undefined,
    margins: { top: 80, bottom: 80, left: 160, right: 160 },
    verticalAlign: opts.vAlign || VerticalAlign.TOP,
    columnSpan: opts.span,
    children,
  });
}

function headerCell(text, width, bg = DARK_NAVY) {
  return new TableCell({
    borders: borders("CCCCCC"),
    width: { size: width, type: WidthType.DXA },
    shading: { fill: bg, type: ShadingType.CLEAR },
    margins: { top: 100, bottom: 100, left: 160, right: 160 },
    verticalAlign: VerticalAlign.CENTER,
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text, bold: true, color: "FFFFFF", size: 18, font: "Arial" })]
    })]
  });
}

function p(text, opts = {}) {
  return new Paragraph({
    alignment: opts.align || AlignmentType.LEFT,
    spacing: { before: opts.spaceBefore ?? 60, after: opts.spaceAfter ?? 60 },
    children: [new TextRun({
      text,
      bold: opts.bold,
      italic: opts.italic,
      color: opts.color || DARK_TEXT,
      size: opts.size || 20,
      font: "Arial",
    })]
  });
}

function mixedP(runs, opts = {}) {
  return new Paragraph({
    alignment: opts.align || AlignmentType.LEFT,
    spacing: { before: opts.spaceBefore ?? 60, after: opts.spaceAfter ?? 60 },
    numbering: opts.numbering,
    children: runs.map(r => new TextRun({ ...r, font: "Arial" }))
  });
}

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 160 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: ACCENT_BLUE, space: 6 } },
    children: [new TextRun({ text, bold: true, color: DARK_NAVY, size: 36, font: "Arial" })]
  });
}

function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 280, after: 120 },
    children: [new TextRun({ text, bold: true, color: ACCENT_BLUE, size: 26, font: "Arial" })]
  });
}

function h3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 200, after: 80 },
    children: [new TextRun({ text, bold: true, color: DARK_NAVY, size: 22, font: "Arial" })]
  });
}

function bullet(text, ref = "bullets", bold_prefix = null) {
  const runs = bold_prefix
    ? [new TextRun({ text: bold_prefix + " ", bold: true, color: DARK_TEXT, size: 20, font: "Arial" }),
       new TextRun({ text, color: MID_TEXT, size: 20, font: "Arial" })]
    : [new TextRun({ text, color: MID_TEXT, size: 20, font: "Arial" })];
  return new Paragraph({
    numbering: { reference: ref, level: 0 },
    spacing: { before: 40, after: 40 },
    children: runs
  });
}

function calloutBox(title, text, bg, accentColor) {
  return new Table({
    width: { size: CONTENT_WIDTH, type: WidthType.DXA },
    columnWidths: [CONTENT_WIDTH],
    rows: [new TableRow({
      children: [new TableCell({
        borders: {
          top: { style: BorderStyle.SINGLE, size: 12, color: accentColor },
          bottom: border("CCCCCC"),
          left: { style: BorderStyle.SINGLE, size: 20, color: accentColor },
          right: border("CCCCCC"),
        },
        width: { size: CONTENT_WIDTH, type: WidthType.DXA },
        shading: { fill: bg, type: ShadingType.CLEAR },
        margins: { top: 120, bottom: 120, left: 200, right: 200 },
        children: [
          new Paragraph({
            spacing: { before: 0, after: 60 },
            children: [new TextRun({ text: title, bold: true, color: accentColor, size: 20, font: "Arial" })]
          }),
          new Paragraph({
            spacing: { before: 0, after: 0 },
            children: [new TextRun({ text, color: DARK_TEXT, size: 19, font: "Arial" })]
          })
        ]
      })]
    })]
  });
}

function spacer(pts = 120) {
  return new Paragraph({ spacing: { before: 0, after: pts }, children: [] });
}

// ─────────────────────────── COVER PAGE ───────────────────────────
const coverSection = [
  new Paragraph({ spacing: { before: 1440, after: 0 }, children: [] }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 0, after: 0 },
    children: [new TextRun({ text: "NEXUS", bold: true, color: ACCENT_BLUE, size: 80, font: "Arial" })]
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 60, after: 0 },
    children: [new TextRun({ text: "COMPETITIVE INTELLIGENCE & ARCHITECTURE REPORT", bold: true, color: DARK_NAVY, size: 32, font: "Arial" })]
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 80, after: 0 },
    children: [new TextRun({ text: "Product Reference Analysis: Bud · Tadween · Portify · Mercury Agent · OpenAI Codex · Google Antigravity", color: SUBTLE_TEXT, size: 22, font: "Arial", italic: true })]
  }),
  new Paragraph({ spacing: { before: 400, after: 0 }, children: [] }),
  new Table({
    width: { size: 5400, type: WidthType.DXA },
    columnWidths: [2700, 2700],
    rows: [
      new TableRow({ children: [
        new TableCell({ borders: noBorders(), width: { size: 2700, type: WidthType.DXA }, margins: { top: 60, bottom: 60, left: 160, right: 160 }, children: [p("Prepared by", { color: SUBTLE_TEXT, size: 18 }), p("External Research & QA — NEXUS", { bold: true, color: DARK_NAVY, size: 20 })] }),
        new TableCell({ borders: noBorders(), width: { size: 2700, type: WidthType.DXA }, margins: { top: 60, bottom: 60, left: 160, right: 160 }, children: [p("Date", { color: SUBTLE_TEXT, size: 18 }), p("May 21, 2026", { bold: true, color: DARK_NAVY, size: 20 })] }),
      ]})
    ]
  }),
  new Paragraph({ children: [new PageBreak()] }),
];

// ─────────────────────────── SECTION 1: FEATURE MATRIX ───────────────────────────
const featureMatrixRows = () => {
  const features = [
    ["AI Task Automation / Agents", "✓ Core", "✗", "✗", "✓ Core", "✓ Core", "✓ Core"],
    ["Natural Language Interface", "✓", "✓ (EN/AR)", "✗", "✓", "✓", "✓"],
    ["Resume / Profile Builder", "✗", "✓ Core", "Partial (portfolio)", "✗", "✗", "✗"],
    ["Job Fit / Matching Engine", "✗", "✓ Core", "✗", "✗", "✗", "✗"],
    ["ATS Optimization", "✗", "✓", "✗", "✗", "✗", "✗"],
    ["GitHub / Code Portfolio", "✗", "✗", "✓ Core", "✗", "✗", "✗"],
    ["Persistent Memory / Second Brain", "✓ (skills)", "Workspace", "✗", "✓ Core (SQLite)", "✗", "✗"],
    ["Permission / Guardrail System", "✓", "✗", "✗", "✓ Core", "✓ Sandboxed", "✓ Sandboxed"],
    ["Parallel / Async Task Execution", "✓", "✗", "✗", "Daemon mode", "✓ Core", "✓ Core"],
    ["Multi-Agent Orchestration", "✗", "✗", "✗", "✗", "Sub-agents", "✓ Core"],
    ["Browser Automation", "✓", "✗", "✗", "✓ (fetch)", "✓", "✓"],
    ["Email / SMS / Phone Actions", "✓", "✗", "✗", "✗", "✗", "✗"],
    ["Workflow Scheduling / Cron", "✓", "✗", "✗", "Daemon", "Automations", "✗"],
    ["IDE / Code Editor Integration", "✗", "✗", "✗", "CLI + TUI", "✓ Core", "✓ Core (IDE)"],
    ["Multi-model LLM Support", "✓ (Claude)", "✗", "✗", "Vercel AI SDK", "OpenAI only", "Gemini/Claude/GPT"],
    ["Bilingual / Localization", "✗", "✓ (AR/EN)", "✗", "✗", "✗", "✗"],
    ["Team / Collaboration Features", "✗", "Hiring side", "✗", "✗", "✓", "✓ (multi-agent)"],
    ["Skills / Plugin Marketplace", "✓ Core", "✗", "✗", "✗", "Integrations", "SDK"],
    ["Artifact-Based Output (screenshots, replays)", "✓", "✗", "✓ (graphs)", "✗", "✓", "✓ Core"],
    ["API / SDK Access", "✗", "✗", "✗", "CLI", "✓ Full API", "✓ Full SDK"],
  ];

  const headers = new TableRow({
    tableHeader: true,
    children: [
      headerCell("Feature", COL(27, 100)),
      headerCell("Bud", COL(12, 100)),
      headerCell("Tadween", COL(12, 100)),
      headerCell("Portify", COL(12, 100)),
      headerCell("Mercury Agent", COL(13, 100)),
      headerCell("OAI Codex", COL(12, 100)),
      headerCell("Google\nAntigravity", COL(12, 100)),
    ]
  });

  const rows = features.map((row, idx) => {
    const bg = idx % 2 === 0 ? "FFFFFF" : LIGHT_GRAY_BG;
    return new TableRow({ children: [
      cell([p(row[0], { bold: true, size: 18, color: DARK_NAVY })], { width: COL(27, 100), bg }),
      cell([p(row[1], { size: 18, color: row[1].startsWith("✓") ? ACCENT_GREEN : row[1] === "✗" ? ACCENT_RED : MID_TEXT, bold: row[1].startsWith("✓ Core") })], { width: COL(12, 100), bg }),
      cell([p(row[2], { size: 18, color: row[2].startsWith("✓") ? ACCENT_GREEN : row[2] === "✗" ? ACCENT_RED : MID_TEXT, bold: row[2].startsWith("✓ Core") })], { width: COL(12, 100), bg }),
      cell([p(row[3], { size: 18, color: row[3].startsWith("✓") ? ACCENT_GREEN : row[3] === "✗" ? ACCENT_RED : MID_TEXT, bold: row[3].startsWith("✓ Core") })], { width: COL(12, 100), bg }),
      cell([p(row[4], { size: 18, color: row[4].startsWith("✓") ? ACCENT_GREEN : row[4] === "✗" ? ACCENT_RED : MID_TEXT, bold: row[4].startsWith("✓ Core") })], { width: COL(13, 100), bg }),
      cell([p(row[5], { size: 18, color: row[5].startsWith("✓") ? ACCENT_GREEN : row[5] === "✗" ? ACCENT_RED : MID_TEXT, bold: row[5].startsWith("✓ Core") })], { width: COL(12, 100), bg }),
      cell([p(row[6], { size: 18, color: row[6].startsWith("✓") ? ACCENT_GREEN : row[6] === "✗" ? ACCENT_RED : MID_TEXT, bold: row[6].startsWith("✓ Core") })], { width: COL(12, 100), bg }),
    ]});
  });

  return [headers, ...rows];
};

// ─────────────────────────── SECTION 2: PATTERNS TO COPY ───────────────────────────
const patternsToCopy = [
  {
    title: "Artifact-Based Output Transparency (Bud + Antigravity)",
    body: "Every automated action should surface a tangible proof artifact: screenshot, summary card, activity replay log, or downloadable file. Users should never wonder if the system \"did something.\" NEXUS should surface action receipts on every Recruitment Hub pipeline step and every Omega Ops execution."
  },
  {
    title: "Permission-Scoped Execution (Mercury Agent + Codex)",
    body: "Enforce folder-level, project-level, and action-level scope before running any agentic operation. Blocklists (no sudo, no rm -rf, no mass delete) must exist at the kernel of NEXUS Command Center. All sensitive actions require an explicit Approve/Reject UI before execution—never fire-and-forget."
  },
  {
    title: "Persistent Structured Memory (Mercury Agent)",
    body: "Use SQLite (or Supabase) with full-text search for long-term agent memory. Auto-extract 1–3 structured facts per interaction. Run nightly consolidation jobs. Assign confidence scores and set stale-memory pruning intervals. NEXUS can use this for candidate history, ops run logs, and Command Center context."
  },
  {
    title: "Skills/Plugin Architecture (Bud)",
    body: "Decouple NEXUS capabilities as discrete, independently deployable skills or modules. Each skill has an inputs schema, outputs schema, auth config, and test harness. This prevents monolith bloat and lets teams ship Recruitment Hub features without touching Omega Ops or Command Center code."
  },
  {
    title: "Job Fit Scoring with Gap Analysis (Tadween)",
    body: "Don't just show a match percentage. Show a breakdown: skill match, experience match, seniority alignment, and keyword fit — each scored separately. Then provide a concrete action list for closing gaps. NEXUS Recruitment Hub should present recruiter-facing gap analysis cards per candidate."
  },
  {
    title: "Multi-Agent Orchestration with Workspaces (Google Antigravity)",
    body: "Spawn isolated agent workspaces per task. Each workspace has its own context, tools, and outputs. A manager surface shows all running agents in one view. NEXUS Command Center should expose an \"Ops Board\" showing all active Omega Ops agents, their status, and their artifact trail."
  },
  {
    title: "Auto-Portfolio from Work Artifacts (Portify)",
    body: "Every NEXUS candidate should have an auto-generated \"NEXUS Profile Card\" that assembles their uploaded documents, match scores, and skill tags into a shareable link. No manual curation required — pull from existing data and auto-format into a recruiter-shareable card."
  },
  {
    title: "Sandboxed Parallel Execution with Worktrees (OpenAI Codex)",
    body: "Run long-running tasks in isolated sandboxes (containers or edge functions) with Git-worktree-style state isolation. Each Omega Ops run should be sandboxed so that a failing task cannot corrupt the main job queue. Results merge back only after successful completion."
  }
];

// ─────────────────────────── SECTION 3: WHAT TO AVOID ───────────────────────────
const thingsToAvoid = [
  {
    title: "Single-Region Language Lock (Tadween anti-pattern)",
    body: "Tadween's deep MENA/Arabic specialization makes global expansion costly. NEXUS should build i18n support from day 1 — use locale keys, not hardcoded strings — so that Arabic, French, and English support can flip on without code changes."
  },
  {
    title: "Monolithic LLM Coupling (OpenAI Codex risk)",
    body: "Codex is tightly coupled to OpenAI models only. NEXUS must use an abstraction layer (e.g., Vercel AI SDK or LiteLLM) so that switching between Claude, GPT-5, or Gemini is a config change, not a migration. Never hardcode an LLM provider into business logic."
  },
  {
    title: "No Guardrails on Agent Actions (generic agentic risk)",
    body: "Tools that go straight to \"allow all\" mode (like Mercury's permissive option) become liability in enterprise contexts. NEXUS should never expose an Allow All mode to non-admin users. Every external action (email send, file delete, API call) must be gated by role-based permission."
  },
  {
    title: "Portfolio-Only Positioning Without Workflow Integration (Portify limitation)",
    body: "Portify is a standalone showcase tool with no pipeline integration. NEXUS should avoid building profile features that are detached from the recruitment workflow. Every profile artifact must connect back to a pipeline stage, candidate record, or ops run."
  },
  {
    title: "Over-Reliance on Markdown/Plain Files for Memory (Mercury risk)",
    body: "Mercury's soul.md and persona.md system is elegant for personal agents but brittle at scale. NEXUS should use a structured database (Supabase rows with JSONB) for all persistent agent context, not flat files. Flat files create merge conflicts and make auditability impossible."
  },
  {
    title: "No Audit Log on Agent Actions",
    body: "Several reviewed products surface results without a traceable audit trail. NEXUS Command Center must write an immutable log for every agent action: who triggered it, what parameters were sent, what external service was called, and what the result was. This is non-negotiable for enterprise and compliance use cases."
  },
  {
    title: "Closed SDK / No External Integration Path (Tadween limitation)",
    body: "Tadween has no public API or integration hooks for external ATS systems. NEXUS should expose a REST + webhook API from the beginning so third-party HR tools (Workday, Greenhouse, Lever) can push/pull data. Closed systems lose enterprise deals."
  }
];

// ─────────────────────────── SECTION 4: 10 FEATURES IN <14 DAYS ───────────────────────────
const quickFeatures = [
  { id: "F01", name: "Candidate Profile Auto-Card", days: "2–3 days", desc: "Auto-generate a shareable candidate profile card (PDF + link) from uploaded CV data. Pull name, skills, experience tags, and match score. No manual formatting." },
  { id: "F02", name: "Job Fit Score with Gap Breakdown", days: "3–4 days", desc: "Paste a job description → get a structured match report: skills matched, skills missing, experience alignment, and 3 concrete improvement actions. LLM-powered with structured JSON output." },
  { id: "F03", name: "Ops Run Activity Feed", days: "2 days", desc: "Real-time activity feed in Command Center showing every Omega Ops action with timestamp, status badge (success/fail/pending), and artifact link. Stored in Supabase, polled or Realtime." },
  { id: "F04", name: "Permission Approval Queue", days: "2–3 days", desc: "Any agent action flagged as sensitive (email send, external API call, file delete) goes into an Approve/Reject queue in Command Center. Action executes only after approval. Full audit log written regardless." },
  { id: "F05", name: "Recruitment Pipeline Kanban", days: "3–4 days", desc: "Drag-and-drop Kanban board for Recruitment Hub: Applied → Screened → Interview → Offer → Hired. Candidate cards show match score and last action. Stage changes trigger Omega Ops hooks." },
  { id: "F06", name: "ATS Keyword Optimizer", days: "2 days", desc: "Upload CV + paste job description → highlight missing ATS keywords → output a revised skills section. LLM extracts keywords from JD, diffs against CV, returns inline suggestions." },
  { id: "F07", name: "Agent Memory Fact Extractor", days: "2–3 days", desc: "After each major action (interview logged, ops run completed), auto-extract 1–3 structured facts to a Supabase memory table. Facts have confidence score, source, and expiry. Queryable by future agents." },
  { id: "F08", name: "Scheduled Ops Runner (Cron UI)", days: "3 days", desc: "Visual cron scheduler in Command Center. User picks a task template, sets a frequency, and gets a next-run countdown. Runs stored as background jobs. Results appear in Activity Feed (F03)." },
  { id: "F09", name: "Artifact Proof Receipt", days: "1–2 days", desc: "After every automated action, emit a structured receipt card: action type, timestamp, output summary, and a link to the full artifact. Display inline in the ops feed and optionally email to operator." },
  { id: "F10", name: "Role-Based Access Control (RBAC) Scaffold", days: "3–4 days", desc: "Supabase RLS policies + frontend role gates for Admin, Recruiter, Ops Operator, Viewer roles. Each role sees only its relevant modules. Admin can approve permission queue (F04). Scaffold now, add granular policies per sprint." },
];

// ─────────────────────────── SECTION 5: PRIORITY ORDER ───────────────────────────
const priorities = {
  P0: {
    label: "P0 — Must-Have Before Anything Else",
    color: ACCENT_RED,
    bg: LIGHT_RED_BG,
    items: [
      "RBAC Scaffold (F10) — Without role gates, no enterprise demo is safe",
      "Permission Approval Queue (F04) — Core trust signal for Command Center",
      "Ops Run Activity Feed (F03) — Operators need live visibility immediately",
      "Artifact Proof Receipt (F09) — Every action must be accountable",
    ]
  },
  P1: {
    label: "P1 — Core Product Differentiation",
    color: ACCENT_ORANGE,
    bg: LIGHT_ORANGE_BG,
    items: [
      "Recruitment Pipeline Kanban (F05) — Primary Recruitment Hub interaction layer",
      "Job Fit Score with Gap Breakdown (F02) — Key AI value prop vs. competitors",
      "Agent Memory Fact Extractor (F07) — NEXUS persistent intelligence advantage",
      "Scheduled Ops Runner (F08) — Omega Ops automation backbone",
    ]
  },
  P2: {
    label: "P2 — Enhancers and Differentiators",
    color: ACCENT_GREEN,
    bg: LIGHT_GREEN_BG,
    items: [
      "Candidate Profile Auto-Card (F01) — Quality-of-life for recruiters",
      "ATS Keyword Optimizer (F06) — Candidate-facing value add",
    ]
  }
};

// ─────────────────────────── SECTION 6: IMPLEMENTATION TASKS ───────────────────────────
const implTasks = {
  "Recruitment Hub": [
    { task: "RH-01", name: "Candidate Ingestion Pipeline", desc: "Build CV upload → parse → normalize → store flow. Support PDF, DOCX, LinkedIn URL. Store parsed data as structured JSON in Supabase candidates table. Emit parsed_at timestamp and parser_version.", priority: "P0" },
    { task: "RH-02", name: "Job Description Indexer", desc: "Allow recruiters to create/import JDs. Extract required skills, seniority, domain, and keywords using LLM → store as structured job_requirements record. All match scoring references this record.", priority: "P0" },
    { task: "RH-03", name: "Job Fit Scoring Engine", desc: "For each candidate-job pair, compute a 0–100 composite score from: skill match (40%), experience match (30%), seniority alignment (20%), keyword fit (10%). Write score + breakdown to match_scores table.", priority: "P0" },
    { task: "RH-04", name: "Recruitment Pipeline Kanban UI", desc: "React drag-and-drop Kanban with columns: Applied, Screened, Interview, Offer, Hired. Cards show avatar, name, match score badge, and last action. Column moves trigger stage_change events consumed by Omega Ops.", priority: "P1" },
    { task: "RH-05", name: "Gap Analysis Report Card", desc: "Per candidate-job pair: show top 3 matched skills, top 3 missing skills, experience gap (in years), and 3 recommended actions. Displayed as a collapsible panel on the candidate card.", priority: "P1" },
    { task: "RH-06", name: "Auto Profile Card Generator", desc: "On demand or on pipeline entry: generate a styled PDF + shareable URL candidate profile card. Pulls from parsed CV, match scores, and skill tags. Uses PDF generation (Puppeteer or React-PDF).", priority: "P2" },
    { task: "RH-07", name: "ATS Keyword Optimizer Widget", desc: "Recruiter/candidate tool: diff CV content against JD keywords. Return inline markup showing +adds and -misses with an optimized skills section. LLM call with structured prompt.", priority: "P2" },
  ],
  "Omega Ops": [
    { task: "OO-01", name: "Task Queue and Runner", desc: "Implement a persistent job queue (Supabase + Edge Functions or BullMQ). Each task has: type, params, status (queued/running/done/failed), created_at, started_at, completed_at, result, error. Retry logic with exponential backoff.", priority: "P0" },
    { task: "OO-02", name: "Sandboxed Execution Layer", desc: "Each ops run executes in an isolated context (Edge Function per run or Docker container). No shared state between runs. Output is written to artifacts table. Failed runs cannot affect the queue.", priority: "P0" },
    { task: "OO-03", name: "Permission Gate + Approval Queue", desc: "Flag actions by risk level (low/medium/high). Medium and high actions emit a pending_approval record. A Command Center UI exposes Approve/Reject. Action proceeds only on approval. All decisions are audit-logged.", priority: "P0" },
    { task: "OO-04", name: "Action Audit Log", desc: "Immutable append-only table: ops_audit_log (id, run_id, action_type, actor_id, target_resource, params_hash, status, error, created_at). Indexed by run_id and actor_id. Exportable to CSV.", priority: "P0" },
    { task: "OO-05", name: "Scheduled Ops Runner (Cron UI)", desc: "Admin UI to create cron schedules for recurring ops tasks. Persist schedule in Supabase. Trigger via cron-based Edge Function or Vercel cron. Show next_run, last_run, last_status on each schedule card.", priority: "P1" },
    { task: "OO-06", name: "Agent Memory Module", desc: "Post-run fact extraction: call LLM to extract 0–3 structured facts from run output. Store in agent_memory (fact, source_run_id, confidence, expires_at). Full-text search index. Consolidation job runs nightly.", priority: "P1" },
    { task: "OO-07", name: "Multi-Ops Orchestrator", desc: "Allow one ops plan to spawn sub-tasks in parallel. Parent task waits for all children. Results are aggregated into a single parent artifact. Show parent+children in the Command Center Ops Board as a tree view.", priority: "P2" },
  ],
  "NEXUS Command Center": [
    { task: "CC-01", name: "RBAC with Supabase RLS", desc: "Define 4 roles: Admin, Recruiter, Ops Operator, Viewer. Supabase RLS policies enforce data visibility per role. Frontend route guards and component-level gating. Admin role required for permission queue and cron management.", priority: "P0" },
    { task: "CC-02", name: "Real-Time Activity Feed", desc: "Supabase Realtime subscription on ops_runs, stage_changes, audit_log tables. Display as a chronological feed with type icon, status badge, actor, and timestamp. Filterable by module (Recruitment / Ops), status, and date range.", priority: "P0" },
    { task: "CC-03", name: "Permission Approval Center", desc: "Tabbed UI: Pending / Approved / Rejected. Each pending item shows: action type, requester, target resource, and risk level. Approve/Reject buttons with optional note. Actions locked for non-Admin roles.", priority: "P0" },
    { task: "CC-04", name: "Multi-Agent Ops Board", desc: "Dashboard showing all active + recent Omega Ops runs. Each card: task name, status, progress %, current step, artifact count, duration. Click to drill into step-by-step artifact trail. Filter by status and operator.", priority: "P1" },
    { task: "CC-05", name: "Metrics & KPI Dashboard", desc: "Auto-computed metrics: avg match score per JD, pipeline conversion rate by stage, ops success rate, avg processing time. Refreshed every 5 min. Exportable. Visible to Admin + Recruiter roles.", priority: "P1" },
    { task: "CC-06", name: "Notification Center", desc: "In-app notification bell showing: approvals needed, pipeline stage changes, ops failures, memory consolidation results. Mark-read, mark-all-read. Optional email/Telegram delivery via background job.", priority: "P1" },
    { task: "CC-07", name: "Artifact Viewer + Export", desc: "Centralized artifact library: browse, search, preview, and download any artifact from any ops run or recruitment action. Artifacts tagged by type (PDF, JSON, screenshot, report). Expiry policy with admin-managed retention.", priority: "P2" },
  ]
};

// ─────────────────────────── SECTION 7: SECURITY RISKS ───────────────────────────
const securityRisks = [
  { risk: "Prompt Injection via CV/JD Content", severity: "CRITICAL", rule: "Never pass raw user-uploaded text directly as a system prompt. Always wrap in a structured template with delimiters. Validate and sanitize all LLM inputs. Log the raw input separately from the sanitized version." },
  { risk: "Excessive LLM Tool Permissions", severity: "HIGH", rule: "LLM agents must never have access to delete, update-all, or admin-scope database operations. Scope each tool call to the minimum required action (read-only or single-record writes). Use allowlisted tool schemas per agent role." },
  { risk: "Unscoped Agent File/Shell Access", severity: "HIGH", rule: "If any NEXUS agent executes shell commands or reads files, enforce explicit folder-scope limits and a blocklist (no sudo, no rm, no curl to external IPs not in allowlist). Mirror Mercury Agent's blocklist approach." },
  { risk: "Insecure Direct Object References (IDOR)", severity: "HIGH", rule: "All Supabase queries must pass through RLS policies. Never expose raw database IDs in public URLs without validating the requesting user's role. Add RLS checks for every table a non-Admin role can access." },
  { risk: "Credential Exposure in Agent Prompts", severity: "HIGH", rule: "Never pass API keys, tokens, or PII into LLM prompt context. Use environment variable injection at the server level. LLM calls should receive only sanitized, pseudonymized data references, never raw credentials." },
  { risk: "Unthrottled LLM Calls (Cost + DoS)", severity: "MEDIUM", rule: "Implement per-user and per-ops-run token budgets. Hard-cap daily spend at the API key level. Rate-limit the job queue to prevent a runaway automation from burning token quota. Alert at 70% of daily budget (mirror Mercury's pattern)." },
  { risk: "Audit Log Tampering", severity: "MEDIUM", rule: "The ops_audit_log table must have INSERT-only RLS (no UPDATE, no DELETE, even for Admin). Export logs to an external sink (object storage) on a scheduled basis. Hash each row on write and verify on export." },
  { risk: "Overly Permissive CORS on API Routes", severity: "MEDIUM", rule: "Lock CORS origins to known NEXUS frontend domains only. Never use wildcard (*) in production. Validate Origin headers server-side. Apply on all Supabase Edge Functions and any custom API routes." },
  { risk: "CV/PII Data Residency", severity: "MEDIUM", rule: "Candidate CV data is PII. Encrypt at rest in Supabase (AES-256). Do not pass full CV text to external LLM APIs — send only extracted structured fields or pseudonymized summaries. Document your data residency policy before launch." },
  { risk: "Stale Memory Poisoning", severity: "LOW", rule: "Agent memory facts extracted from LLM output can be hallucinated. Apply a confidence threshold (>0.7) before persisting. Flag low-confidence facts for human review. Purge facts older than 90 days unless explicitly pinned." },
];

// ─────────────────────────── ASSEMBLE DOCUMENT ───────────────────────────

const numbering = {
  config: [
    {
      reference: "bullets",
      levels: [{
        level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 720, hanging: 360 } } }
      }]
    },
    {
      reference: "numbers",
      levels: [{
        level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 720, hanging: 360 } } }
      }]
    },
  ]
};

const docStyles = {
  default: { document: { run: { font: "Arial", size: 20, color: DARK_TEXT } } },
  paragraphStyles: [
    { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { size: 36, bold: true, font: "Arial", color: DARK_NAVY },
      paragraph: { spacing: { before: 360, after: 160 }, outlineLevel: 0 } },
    { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { size: 26, bold: true, font: "Arial", color: ACCENT_BLUE },
      paragraph: { spacing: { before: 280, after: 120 }, outlineLevel: 1 } },
    { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { size: 22, bold: true, font: "Arial", color: DARK_NAVY },
      paragraph: { spacing: { before: 200, after: 80 }, outlineLevel: 2 } },
  ]
};

const sectionProps = {
  page: {
    size: { width: 12240, height: 15840 },
    margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
  },
  headers: {
    default: new Header({
      children: [new Paragraph({
        border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: ACCENT_BLUE, space: 6 } },
        spacing: { before: 0, after: 120 },
        children: [
          new TextRun({ text: "NEXUS", bold: true, color: ACCENT_BLUE, size: 18, font: "Arial" }),
          new TextRun({ text: "  |  Competitive Intelligence & Architecture Report  |  Confidential", color: SUBTLE_TEXT, size: 16, font: "Arial" }),
        ]
      })]
    })
  },
  footers: {
    default: new Footer({
      children: [new Paragraph({
        border: { top: { style: BorderStyle.SINGLE, size: 4, color: MID_GRAY, space: 6 } },
        spacing: { before: 120, after: 0 },
        alignment: AlignmentType.RIGHT,
        children: [
          new TextRun({ text: "Page ", color: SUBTLE_TEXT, size: 16, font: "Arial" }),
          new TextRun({ children: [PageNumber.CURRENT], color: SUBTLE_TEXT, size: 16, font: "Arial" }),
          new TextRun({ text: " of ", color: SUBTLE_TEXT, size: 16, font: "Arial" }),
          new TextRun({ children: [PageNumber.TOTAL_PAGES], color: SUBTLE_TEXT, size: 16, font: "Arial" }),
        ]
      })]
    })
  }
};

const mainContent = [
  // TOC
  h1("Table of Contents"),
  new TableOfContents("Contents", { hyperlink: true, headingStyleRange: "1-3" }),
  new Paragraph({ children: [new PageBreak()] }),

  // SECTION 1
  h1("1. Feature Matrix"),
  p("The following matrix compares core capabilities across the six reference products. ✓ Core indicates a primary product differentiator. ✓ indicates present. ✗ indicates absent.", { color: MID_TEXT, spaceAfter: 200 }),
  new Table({
    width: { size: CONTENT_WIDTH, type: WidthType.DXA },
    columnWidths: [COL(27, 100), COL(12, 100), COL(12, 100), COL(12, 100), COL(13, 100), COL(12, 100), COL(12, 100)],
    rows: featureMatrixRows()
  }),
  spacer(240),
  new Paragraph({ children: [new PageBreak()] }),

  // SECTION 2
  h1("2. Patterns NEXUS Should Copy"),
  p("The following are architectural and UX patterns — not branding — that have proven effective across the reference products and should be adapted for NEXUS.", { color: MID_TEXT, spaceAfter: 160 }),
  ...patternsToCopy.map((item, i) => [
    h3(`${i + 1}. ${item.title}`),
    p(item.body, { color: MID_TEXT, spaceAfter: 160 }),
  ]).flat(),
  new Paragraph({ children: [new PageBreak()] }),

  // SECTION 3
  h1("3. What to Avoid"),
  p("Anti-patterns and architectural pitfalls observed across reference products.", { color: MID_TEXT, spaceAfter: 160 }),
  ...thingsToAvoid.map((item, i) => [
    h3(`${i + 1}. ${item.title}`),
    p(item.body, { color: MID_TEXT, spaceAfter: 160 }),
  ]).flat(),
  new Paragraph({ children: [new PageBreak()] }),

  // SECTION 4
  h1("4. 10 Features Buildable in Under 14 Days"),
  p("Each feature is scoped for a 1–2 engineer sprint with clear input/output contracts and no external dependencies beyond Supabase and LLM API access.", { color: MID_TEXT, spaceAfter: 200 }),
  new Table({
    width: { size: CONTENT_WIDTH, type: WidthType.DXA },
    columnWidths: [COL(6, 100), COL(22, 100), COL(8, 100), COL(64, 100)],
    rows: [
      new TableRow({
        tableHeader: true,
        children: [
          headerCell("ID", COL(6, 100)),
          headerCell("Feature", COL(22, 100)),
          headerCell("Est.", COL(8, 100)),
          headerCell("Description", COL(64, 100)),
        ]
      }),
      ...quickFeatures.map((f, idx) => {
        const bg = idx % 2 === 0 ? "FFFFFF" : LIGHT_GRAY_BG;
        return new TableRow({ children: [
          cell([p(f.id, { bold: true, size: 18, color: ACCENT_BLUE })], { width: COL(6, 100), bg }),
          cell([p(f.name, { bold: true, size: 18, color: DARK_NAVY })], { width: COL(22, 100), bg }),
          cell([p(f.days, { size: 17, color: MID_TEXT })], { width: COL(8, 100), bg }),
          cell([p(f.desc, { size: 18, color: MID_TEXT })], { width: COL(64, 100), bg }),
        ]});
      })
    ]
  }),
  spacer(240),
  new Paragraph({ children: [new PageBreak()] }),

  // SECTION 5
  h1("5. Priority Order: P0, P1, P2"),
  ...Object.entries(priorities).map(([key, val]) => [
    spacer(80),
    calloutBox(val.label,
      val.items.map((item, i) => `${i + 1}. ${item}`).join("\n"),
      val.bg, val.color),
    spacer(80),
  ]).flat(),
  new Paragraph({ children: [new PageBreak()] }),

  // SECTION 6
  h1("6. Implementation Tasks by Module"),

  // Recruitment Hub
  h2("6.1 Recruitment Hub"),
  new Table({
    width: { size: CONTENT_WIDTH, type: WidthType.DXA },
    columnWidths: [COL(7, 100), COL(22, 100), COL(8, 100), COL(63, 100)],
    rows: [
      new TableRow({
        tableHeader: true,
        children: [
          headerCell("Task", COL(7, 100)),
          headerCell("Name", COL(22, 100)),
          headerCell("Priority", COL(8, 100)),
          headerCell("Description", COL(63, 100)),
        ]
      }),
      ...implTasks["Recruitment Hub"].map((t, idx) => {
        const bg = idx % 2 === 0 ? "FFFFFF" : LIGHT_GRAY_BG;
        const prioColor = t.priority === "P0" ? ACCENT_RED : t.priority === "P1" ? ACCENT_ORANGE : ACCENT_GREEN;
        return new TableRow({ children: [
          cell([p(t.task, { bold: true, size: 17, color: ACCENT_BLUE })], { width: COL(7, 100), bg }),
          cell([p(t.name, { bold: true, size: 18, color: DARK_NAVY })], { width: COL(22, 100), bg }),
          cell([p(t.priority, { bold: true, size: 18, color: prioColor })], { width: COL(8, 100), bg }),
          cell([p(t.desc, { size: 18, color: MID_TEXT })], { width: COL(63, 100), bg }),
        ]});
      })
    ]
  }),
  spacer(160),

  // Omega Ops
  h2("6.2 Omega Ops"),
  new Table({
    width: { size: CONTENT_WIDTH, type: WidthType.DXA },
    columnWidths: [COL(7, 100), COL(22, 100), COL(8, 100), COL(63, 100)],
    rows: [
      new TableRow({
        tableHeader: true,
        children: [
          headerCell("Task", COL(7, 100)),
          headerCell("Name", COL(22, 100)),
          headerCell("Priority", COL(8, 100)),
          headerCell("Description", COL(63, 100)),
        ]
      }),
      ...implTasks["Omega Ops"].map((t, idx) => {
        const bg = idx % 2 === 0 ? "FFFFFF" : LIGHT_GRAY_BG;
        const prioColor = t.priority === "P0" ? ACCENT_RED : t.priority === "P1" ? ACCENT_ORANGE : ACCENT_GREEN;
        return new TableRow({ children: [
          cell([p(t.task, { bold: true, size: 17, color: ACCENT_BLUE })], { width: COL(7, 100), bg }),
          cell([p(t.name, { bold: true, size: 18, color: DARK_NAVY })], { width: COL(22, 100), bg }),
          cell([p(t.priority, { bold: true, size: 18, color: prioColor })], { width: COL(8, 100), bg }),
          cell([p(t.desc, { size: 18, color: MID_TEXT })], { width: COL(63, 100), bg }),
        ]});
      })
    ]
  }),
  spacer(160),

  // Command Center
  h2("6.3 NEXUS Command Center"),
  new Table({
    width: { size: CONTENT_WIDTH, type: WidthType.DXA },
    columnWidths: [COL(7, 100), COL(22, 100), COL(8, 100), COL(63, 100)],
    rows: [
      new TableRow({
        tableHeader: true,
        children: [
          headerCell("Task", COL(7, 100)),
          headerCell("Name", COL(22, 100)),
          headerCell("Priority", COL(8, 100)),
          headerCell("Description", COL(63, 100)),
        ]
      }),
      ...implTasks["NEXUS Command Center"].map((t, idx) => {
        const bg = idx % 2 === 0 ? "FFFFFF" : LIGHT_GRAY_BG;
        const prioColor = t.priority === "P0" ? ACCENT_RED : t.priority === "P1" ? ACCENT_ORANGE : ACCENT_GREEN;
        return new TableRow({ children: [
          cell([p(t.task, { bold: true, size: 17, color: ACCENT_BLUE })], { width: COL(7, 100), bg }),
          cell([p(t.name, { bold: true, size: 18, color: DARK_NAVY })], { width: COL(22, 100), bg }),
          cell([p(t.priority, { bold: true, size: 18, color: prioColor })], { width: COL(8, 100), bg }),
          cell([p(t.desc, { size: 18, color: MID_TEXT })], { width: COL(63, 100), bg }),
        ]});
      })
    ]
  }),
  spacer(240),
  new Paragraph({ children: [new PageBreak()] }),

  // SECTION 7
  h1("7. Security Risks and Safe Usage Rules"),
  p("The following risks were identified by analyzing the security model gaps across all six reference products and applying them to NEXUS's architecture context. Severity levels: CRITICAL, HIGH, MEDIUM, LOW.", { color: MID_TEXT, spaceAfter: 200 }),
  new Table({
    width: { size: CONTENT_WIDTH, type: WidthType.DXA },
    columnWidths: [COL(30, 100), COL(9, 100), COL(61, 100)],
    rows: [
      new TableRow({
        tableHeader: true,
        children: [
          headerCell("Risk", COL(30, 100)),
          headerCell("Severity", COL(9, 100)),
          headerCell("Safe Usage Rule", COL(61, 100)),
        ]
      }),
      ...securityRisks.map((r, idx) => {
        const bg = idx % 2 === 0 ? "FFFFFF" : LIGHT_GRAY_BG;
        const sevColor = r.severity === "CRITICAL" ? ACCENT_RED
          : r.severity === "HIGH" ? ACCENT_ORANGE
          : r.severity === "MEDIUM" ? ACCENT_BLUE
          : ACCENT_GREEN;
        const sevBg = r.severity === "CRITICAL" ? "FFEBEE"
          : r.severity === "HIGH" ? "FEF3E2"
          : r.severity === "MEDIUM" ? LIGHT_BLUE_BG
          : LIGHT_GREEN_BG;
        return new TableRow({ children: [
          cell([p(r.risk, { bold: true, size: 18, color: DARK_NAVY })], { width: COL(30, 100), bg }),
          cell([p(r.severity, { bold: true, size: 17, color: sevColor })], { width: COL(9, 100), bg: sevBg }),
          cell([p(r.rule, { size: 18, color: MID_TEXT })], { width: COL(61, 100), bg }),
        ]});
      })
    ]
  }),
  spacer(240),

  // Closing
  new Paragraph({ children: [new PageBreak()] }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 720, after: 0 },
    children: [new TextRun({ text: "END OF REPORT", bold: true, color: SUBTLE_TEXT, size: 22, font: "Arial" })]
  }),
  p("This document was prepared under the NEXUS external research and QA engagement. All product analysis is based on publicly available information only. No private credentials, employee data, or proprietary systems were accessed.", { color: SUBTLE_TEXT, size: 17, align: AlignmentType.CENTER, spaceBefore: 120 }),
];

const doc = new Document({
  numbering,
  styles: docStyles,
  sections: [
    // Cover page (no header/footer)
    {
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
        }
      },
      children: coverSection,
    },
    // Main content with header/footer
    {
      properties: sectionProps,
      headers: sectionProps.headers,
      footers: sectionProps.footers,
      children: mainContent,
    }
  ]
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/home/user/computer/nexus-research-report/NEXUS_Competitive_Intelligence_Report.docx", buf);
  console.log("Done.");
}).catch(err => { console.error(err); process.exit(1); });
