#!/usr/bin/env python3
"""
search_nexus_md.py
──────────────────
NEXUS MD Search Engine — CLI

Usage:
  python search_nexus_md.py "human approval"
  python search_nexus_md.py "ARCH-025"
  python search_nexus_md.py "attendance"
  python search_nexus_md.py "entity purity"
  python search_nexus_md.py "recruitment cv cover"

Filters:
  --type     ARCH | DEC | DAM | SIGNAL | FORBIDDEN | CV_RULE | ...
  --impact   Critical | High | Medium | Low
  --layer    "Governance" | "Recruitment" | ...
  --status   STABLE | EXPERIMENTAL | ACTIVE | ANOMALY
  --limit    max results (default 10)
  --verbose  show source traceability
  --stats    show index statistics
  --types    list all record types
  --json     output raw JSON
"""

import sqlite3
import json
import sys
import argparse
import re

DB_PATH = "nexus_md_search.sqlite"

# ── ANSI ──────────────────────────────────────
R  = "\033[0m"
B  = "\033[1m"
DIM= "\033[2m"
UL = "\033[4m"

TYPE_COLOR = {
    "ARCH":          "\033[94m",   # blue
    "DEC":           "\033[96m",   # cyan
    "DAM":           "\033[91m",   # red
    "SIGNAL":        "\033[92m",   # green
    "FORBIDDEN":     "\033[91m",   # red
    "CV_RULE":       "\033[93m",   # yellow
    "REPO_CLASS":    "\033[96m",   # cyan
    "REPO_STRATEGIC":"\033[96m",   # cyan
    "RH_LOG":        "\033[92m",   # green
    "STATUS":        "\033[95m",   # magenta
    "STAGE":         "\033[92m",   # green
    "TRUTH_TYPE":    "\033[93m",   # yellow
}

SEVERITY_COLOR = {
    "Critical": "\033[91m",
    "High":     "\033[93m",
    "Medium":   "\033[94m",
    "Low":      "\033[92m",
}

def tc(t):
    return TYPE_COLOR.get(t, B)

def highlight(text, query_terms):
    """Wrap matched terms in bold."""
    for term in query_terms:
        pattern = re.compile(re.escape(term), re.IGNORECASE)
        text = pattern.sub(lambda m: f"{B}{m.group(0)}{R}", text)
    return text


def connect():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


# ── SEARCH ────────────────────────────────────

def search(query, type_filter=None, impact_filter=None,
           layer_filter=None, status_filter=None, limit=10):
    con = connect()

    # Direct ID lookup
    id_match = re.match(r'^(ARCH|DEC|DAM|SIG|FBD|CVR|REPO|STAGE|STATUS|TRUTH|OMG|RH)-[\w-]+$',
                        query.strip(), re.IGNORECASE)
    if id_match:
        rows = con.execute(
            "SELECT * FROM nexus_md_records WHERE UPPER(id) = UPPER(?)",
            (query.strip(),)
        ).fetchall()
        if rows:
            con.close()
            return rows

    # FTS5 search — build query
    fts_query = query.strip()
    # Escape special FTS5 characters
    fts_query = re.sub(r'[^\w\s\-]', ' ', fts_query)
    fts_query = fts_query.strip()
    if not fts_query:
        con.close()
        return []

    # For multi-word queries: use OR so any word matches, ranked by relevance
    # Include short words (2+ chars) since "cv" is meaningful in NEXUS context
    words = [w for w in fts_query.split() if len(w) >= 2]
    if len(words) > 1:
        fts_query = " OR ".join(words)

    # Build WHERE clause
    where_parts = ["records_fts MATCH ?"]
    params = [fts_query]

    if type_filter:
        where_parts.append("r.type = ?")
        params.append(type_filter.upper())

    if impact_filter:
        where_parts.append("LOWER(r.impact) LIKE ?")
        params.append(f"%{impact_filter.lower()}%")

    if layer_filter:
        where_parts.append("LOWER(r.related_layers) LIKE ?")
        params.append(f"%{layer_filter.lower()}%")

    if status_filter:
        where_parts.append("UPPER(r.truth_status) = UPPER(?)")
        params.append(status_filter)

    params.append(limit)

    sql = f"""
        SELECT r.*, bm25(nexus_md_records_fts) as score
        FROM nexus_md_records_fts
        JOIN nexus_md_records r ON r.rowid = nexus_md_records_fts.rowid
        WHERE {' AND '.join(where_parts)}
        ORDER BY score
        LIMIT ?
    """

    try:
        rows = con.execute(sql, params).fetchall()
    except sqlite3.OperationalError:
        # Fallback: plain LIKE search across all words
        words_like = re.sub(r'[^\w\s\-]', ' ', query).split()
        like_conditions = " OR ".join(
            ["(title LIKE ? OR content LIKE ? OR id LIKE ?)"] * len(words_like)
        )
        like_params = []
        for w in words_like:
            lq = f"%{w}%"
            like_params.extend([lq, lq, lq])
        filter_prefix = f"type = '{type_filter.upper()}' AND " if type_filter else ""
        sql2 = f"SELECT *, NULL as score FROM nexus_md_records WHERE {filter_prefix}({like_conditions}) LIMIT {limit}"
        rows = con.execute(sql2, like_params).fetchall()

    con.close()
    return rows


# ── RENDER ────────────────────────────────────

def render_record(r, query_terms=None, verbose=False, idx=None):
    d = json.loads(r["json_data"]) if r["json_data"] else {}
    t = r["type"]
    color = tc(t)
    prefix = f"  {DIM}{idx}.{R} " if idx else "  "

    print(f"\n{prefix}{color}{B}{r['id']}{R}  {color}{t}{R}  {DIM}{r['truth_status']}{R}")
    title = r["title"] or ""
    if query_terms:
        title = highlight(title, query_terms)
    print(f"  {B}{title}{R}")

    # Type-specific display
    if t == "ARCH":
        if r["reason"]:  print(f"  {DIM}Reason:{R}  {r['reason']}")
        if r["impact"]:
            sc = SEVERITY_COLOR.get(r["impact"], "")
            print(f"  {DIM}Impact:{R}  {sc}{r['impact']}{R}")
        if r["related_layers"]:
            layers = json.loads(r["related_layers"]) if r["related_layers"].startswith("[") else [r["related_layers"]]
            print(f"  {DIM}Layers:{R}  {', '.join(layers)}")

    elif t == "DEC":
        if d.get("rationale"):        print(f"  {DIM}Rationale:{R}  {d['rationale']}")
        if d.get("chosen_solution"):  print(f"  {DIM}Solution:{R}   {d['chosen_solution']}")
        if d.get("context_problem"):  print(f"  {DIM}Problem:{R}    {d['context_problem']}")
        if d.get("rejected_alternatives"): print(f"  {DIM}Rejected:{R}   {d['rejected_alternatives']}")

    elif t == "DAM":
        auth = d.get("authority_level","")
        mode = d.get("execution_mode","")
        cons = d.get("constraints","")
        stk  = d.get("primary_stakeholder","")
        print(f"  {DIM}Authority:{R} {B}{auth}{R}  {DIM}Mode:{R} {mode}")
        if cons: print(f"  {DIM}Constraint:{R} {cons}")
        if stk:  print(f"  {DIM}Stakeholder:{R} {stk}")

    elif t == "SIGNAL":
        val  = d.get("current_value","—")
        thr  = d.get("threshold","—")
        esc  = d.get("escalation_rule","—")
        print(f"  {DIM}Value:{R} {B}{val}{R}  {DIM}Threshold:{R} {thr}  {DIM}Escalation:{R} {esc}")

    elif t == "FORBIDDEN":
        if r["reason"]: print(f"  \033[91mRisk:{R} {r['reason']}")
        if d.get("arch_reference"): print(f"  {DIM}ARCH Ref:{R} {d['arch_reference']}")

    elif t == "CV_RULE":
        rule = d.get("rule_text","") or r["content"]
        print(f"  {rule[:160]}")

    elif t in ("REPO_CLASS","REPO_STRATEGIC"):
        desc = d.get("description") or d.get("strategic_role","")
        if desc: print(f"  {DIM}Role:{R} {desc}")

    elif t == "STAGE":
        mode = d.get("mode","")
        st   = d.get("current_status","")
        print(f"  {DIM}Mode:{R} {mode}  {DIM}Status:{R} {B}{st}{R}")

    elif t == "TRUTH_TYPE":
        if d.get("description"): print(f"  {d['description']}")
        if d.get("example_field"): print(f"  {DIM}Example:{R} {d['example_field']}")

    elif t == "STATUS":
        content = r["content"]
        if query_terms:
            content = highlight(content, query_terms)
        print(f"  {content[:200]}")

    elif t == "RH_LOG":
        if d.get("git_state"): print(f"  {DIM}Git:{R}    {d['git_state']}")
        if d.get("build"):     print(f"  {DIM}Build:{R}  {d['build']}")
        if d.get("next_action"): print(f"  {DIM}Next:{R}   {d['next_action']}")

    if verbose:
        print(f"  {DIM}Source: {r['source_file']} / {r['source_sheet']} / Row {r['source_row']} / Cols {r['source_columns']}{R}")
        if r["tags"]: print(f"  {DIM}Tags: {r['tags']}{R}")


# ── STATS ─────────────────────────────────────

def show_stats():
    con = connect()
    rows = con.execute("SELECT type, count FROM nexus_md_stats").fetchall()
    total = sum(r["count"] for r in rows)
    con.close()
    print(f"\n{B}── NEXUS MD Index Statistics {'─'*28}{R}")
    for r in rows:
        color = tc(r["type"])
        bar = "█" * r["count"]
        print(f"  {color}{r['type']:<20}{R}  {B}{r['count']:>3}{R}  {DIM}{bar}{R}")
    print(f"{'─'*55}")
    print(f"  {'TOTAL':<20}  {B}{total:>3}{R}")
    print(f"{'─'*55}\n")


def list_types():
    con = connect()
    types = [r[0] for r in con.execute(
        "SELECT DISTINCT type FROM nexus_md_records ORDER BY type").fetchall()]
    con.close()
    print(f"\n{B}Record types:{R}")
    for t in types:
        print(f"  {tc(t)}{t}{R}")
    print()


# ── MAIN ──────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="NEXUS MD Search Engine",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python search_nexus_md.py "human approval"
  python search_nexus_md.py "ARCH-025"
  python search_nexus_md.py "attendance"
  python search_nexus_md.py "entity purity"
  python search_nexus_md.py "recruitment cv cover"
  python search_nexus_md.py "memory" --type DEC
  python search_nexus_md.py "governance" --layer "Safety"
  python search_nexus_md.py --stats
        """
    )
    parser.add_argument("query",    nargs="?",           help="Search query or ID (e.g. ARCH-025)")
    parser.add_argument("--type",   "-t",                help="Filter by type: ARCH DEC DAM SIGNAL ...")
    parser.add_argument("--impact", "-i",                help="Filter by impact: Critical High Medium Low")
    parser.add_argument("--layer",  "-l",                help="Filter by related layer")
    parser.add_argument("--status", "-s",                help="Filter by truth status: STABLE EXPERIMENTAL ACTIVE")
    parser.add_argument("--limit",  "-n", type=int, default=10, help="Max results (default 10)")
    parser.add_argument("--verbose","-v", action="store_true",  help="Show source traceability")
    parser.add_argument("--json",   "-j", action="store_true",  help="Output raw JSON")
    parser.add_argument("--stats",        action="store_true",  help="Show index statistics")
    parser.add_argument("--types",        action="store_true",  help="List record types")

    args = parser.parse_args()

    if args.stats:
        show_stats()
        return

    if args.types:
        list_types()
        return

    if not args.query:
        parser.print_help()
        return

    results = search(
        args.query,
        type_filter=args.type,
        impact_filter=args.impact,
        layer_filter=args.layer,
        status_filter=args.status,
        limit=args.limit,
    )

    if args.json:
        out = [json.loads(r["json_data"]) for r in results]
        print(json.dumps(out, ensure_ascii=False, indent=2))
        return

    query_terms = [w for w in args.query.split() if len(w) > 2]
    type_label  = f"  {DIM}[type={args.type}]{R}" if args.type else ""
    print(f"\n{B}Search:{R} \"{args.query}\"{type_label}")
    print(f"{DIM}{'─'*55}{R}")

    if not results:
        print(f"  {DIM}No results.{R}\n")
        return

    print(f"  {DIM}{len(results)} result(s){R}")
    for i, r in enumerate(results, 1):
        render_record(r, query_terms=query_terms, verbose=args.verbose, idx=i)
    print()


if __name__ == "__main__":
    main()
