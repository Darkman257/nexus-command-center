#!/usr/bin/env python3
"""
NEXUS Memory Search CLI
Usage:
  python3 nexus_search.py <query>
  python3 nexus_search.py <query> --type ARCH
  python3 nexus_search.py --list-types
  python3 nexus_search.py --stats
"""

import sqlite3
import json
import sys
import argparse

DB_PATH = "nexus_memory.db"

# ANSI colors
BOLD  = "\033[1m"
BLUE  = "\033[94m"
GREEN = "\033[92m"
CYAN  = "\033[96m"
RED   = "\033[91m"
YELLOW= "\033[93m"
DIM   = "\033[2m"
RESET = "\033[0m"

TYPE_COLORS = {
    "ARCH":           BLUE,
    "DEC":            CYAN,
    "DAM":            RED,
    "SIGNAL":         GREEN,
    "FORBIDDEN":      RED,
    "CV_RULE":        YELLOW,
    "REPO_CLASS":     CYAN,
    "REPO_STRATEGIC": CYAN,
    "STAGE":          GREEN,
    "TRUTH_TYPE":     YELLOW,
    "IMPL":           GREEN,
}

def color_type(t):
    return TYPE_COLORS.get(t, BOLD) + f"[{t}]" + RESET

def print_record(r, verbose=False):
    data = json.loads(r["json_data"])
    tc = TYPE_COLORS.get(r["type"], BOLD)
    print(f"\n{tc}{BOLD}{r['id']}{RESET}  {tc}{r['type']}{RESET}  {DIM}{r['category']}{RESET}")
    print(f"  {BOLD}{r['title']}{RESET}")

    # Type-specific fields
    t = r["type"]
    if t == "ARCH":
        if data.get("reason"):  print(f"  {DIM}Reason:{RESET}  {data['reason']}")
        if data.get("impact"):  print(f"  {DIM}Impact:{RESET}  {data['impact']}")
        if data.get("layers"):  print(f"  {DIM}Layers:{RESET}  {', '.join(data['layers'])}")
    elif t == "DEC":
        if data.get("truth_status"):     print(f"  {DIM}Status:{RESET}  {BOLD}{data['truth_status']}{RESET}")
        if data.get("rationale"):        print(f"  {DIM}Rationale:{RESET} {data['rationale']}")
        if data.get("chosen_solution"):  print(f"  {DIM}Solution:{RESET}  {data['chosen_solution']}")
        if data.get("rejected_alternatives"): print(f"  {DIM}Rejected:{RESET}  {data['rejected_alternatives']}")
    elif t == "DAM":
        print(f"  {DIM}Authority:{RESET} {data.get('authority_level','')}  |  {DIM}Mode:{RESET} {data.get('execution_mode','')}")
        if data.get("constraints"):      print(f"  {DIM}Constraints:{RESET} {data['constraints']}")
        if data.get("primary_stakeholder"): print(f"  {DIM}Stakeholder:{RESET} {data['primary_stakeholder']}")
    elif t == "SIGNAL":
        val = data.get("current_value", "—")
        thr = data.get("threshold", "—")
        esc = data.get("escalation_rule", "—")
        ts  = data.get("truth_status", "")
        print(f"  {DIM}Value:{RESET} {BOLD}{val}{RESET}  {DIM}Threshold:{RESET} {thr}  {DIM}Escalation:{RESET} {esc}  {DIM}Truth:{RESET} {ts}")
    elif t == "FORBIDDEN":
        if data.get("reason"):       print(f"  {RED}Risk:{RESET} {data['reason']}")
        if data.get("arch_reference"): print(f"  {DIM}Ref:{RESET}  {data['arch_reference']}")
    elif t in ("CV_RULE",):
        print(f"  {data.get('rule','')}")
    elif t in ("REPO_CLASS", "REPO_STRATEGIC"):
        desc = data.get("description") or data.get("strategic_role", "")
        if desc: print(f"  {DIM}Role:{RESET} {desc}")
    elif t == "STAGE":
        print(f"  {DIM}Mode:{RESET} {data.get('mode','')}  {DIM}Status:{RESET} {BOLD}{data.get('status','')}{RESET}")
    elif t == "TRUTH_TYPE":
        if data.get("description"): print(f"  {data['description']}")
        if data.get("example_field"): print(f"  {DIM}Example:{RESET} {data['example_field']}")
    elif t == "IMPL":
        print(f"  {DIM}Hub:{RESET} {data.get('hub','')}  {DIM}Status:{RESET} {BOLD}{data.get('status','')}{RESET}")
        if data.get("git_state"): print(f"  {DIM}Git:{RESET} {data['git_state']}")

    if verbose and r["tags"]:
        print(f"  {DIM}Tags: {r['tags']}{RESET}")


def search(query, record_type=None, limit=10, verbose=False):
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row

    if record_type:
        cur = con.execute("""
            SELECT r.id, r.type, r.category, r.title, r.content, r.tags, r.json_data,
                   bm25(records_fts) as score
            FROM records_fts
            JOIN records r ON r.rowid = records_fts.rowid
            WHERE records_fts MATCH ? AND r.type = ?
            ORDER BY score
            LIMIT ?
        """, (query, record_type.upper(), limit))
    else:
        cur = con.execute("""
            SELECT r.id, r.type, r.category, r.title, r.content, r.tags, r.json_data,
                   bm25(records_fts) as score
            FROM records_fts
            JOIN records r ON r.rowid = records_fts.rowid
            WHERE records_fts MATCH ?
            ORDER BY score
            LIMIT ?
        """, (query, limit))

    results = cur.fetchall()
    con.close()
    return results


def show_stats():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    rows = con.execute("SELECT type, category, count FROM stats").fetchall()
    con.close()
    print(f"\n{BOLD}── NEXUS Memory Index Stats ──────────────────{RESET}")
    for r in rows:
        tc = TYPE_COLORS.get(r["type"], BOLD)
        print(f"  {tc}{r['type']:<20}{RESET}  {r['count']:>3}  {DIM}{r['category']}{RESET}")
    print(f"{BOLD}──────────────────────────────────────────────{RESET}")


def list_types():
    con = sqlite3.connect(DB_PATH)
    types = [r[0] for r in con.execute("SELECT DISTINCT type FROM records ORDER BY type").fetchall()]
    con.close()
    print(f"\n{BOLD}Available record types:{RESET}")
    for t in types:
        tc = TYPE_COLORS.get(t, BOLD)
        print(f"  {tc}{t}{RESET}")


def main():
    parser = argparse.ArgumentParser(description="NEXUS Memory Search")
    parser.add_argument("query", nargs="?", help="Search query")
    parser.add_argument("--type", "-t", help="Filter by record type (ARCH, DEC, DAM, SIGNAL, ...)")
    parser.add_argument("--limit", "-n", type=int, default=10, help="Max results (default: 10)")
    parser.add_argument("--verbose", "-v", action="store_true", help="Show tags")
    parser.add_argument("--stats", action="store_true", help="Show index statistics")
    parser.add_argument("--list-types", action="store_true", help="List all record types")

    args = parser.parse_args()

    if args.stats:
        show_stats()
        return

    if args.list_types:
        list_types()
        return

    if not args.query:
        parser.print_help()
        return

    print(f"\n{BOLD}Searching:{RESET} \"{args.query}\"" + (f"  {DIM}[type={args.type}]{RESET}" if args.type else ""))
    results = search(args.query, record_type=args.type, limit=args.limit, verbose=args.verbose)

    if not results:
        print(f"  {DIM}No results found.{RESET}")
        return

    print(f"  {DIM}{len(results)} result(s){RESET}")
    for r in results:
        print_record(r, verbose=args.verbose)
    print()


if __name__ == "__main__":
    main()
