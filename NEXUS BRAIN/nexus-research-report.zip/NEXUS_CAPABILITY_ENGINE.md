# NEXUS Capability Engine

**Version:** 1.0
**Date:** 2026-05-22
**Status:** ACTIVE — Foundational Layer

---

## What Is NEXUS Capability Engine?

NEXUS Capability Engine is the **learning and evolution layer** of NEXUS.

Its job is **not** to store project-specific data. Its job is to **extract reusable intelligence** from every project NEXUS operates in — whether Omega, a sweets factory, a construction company, or any new client — and promote only what is genuinely reusable into the NEXUS Core.

NEXUS Commander is not just a memory query interface.
NEXUS Commander is an **Operating Brain** that learns from every project and updates NEXUS operational capabilities in a structured, governed, human-approved way.

---

## The Separation Law

```
┌─────────────────────────────────────────────────────────────────┐
│  INPUT: Project Update / New Learning / Client Data             │
└────────────────────────┬────────────────────────────────────────┘
                         │ Classification
                         ▼
┌──────────────┬──────────────────┬──────────────┬───────────────┐
│ Project-     │ Reusable         │ Core Rule /  │ Client        │
│ Specific     │ Capability       │ Arch Decision│ Configuration │
│              │                  │              │               │
│ → Stays in   │ → Pending CAP    │ → Pending    │ → Client Pack │
│ Client Pack  │ Patch → Approval │ ARCH Patch   │ only          │
│ ONLY         │ → capabilities   │ → Core Memory│               │
└──────────────┴──────────────────┴──────────────┴───────────────┘
```

**Rule:** Omega apartment names → Omega Business Pack only.
**Rule:** Fleet tracking pattern → Reusable Capability.
**Rule:** "Excel must have preview before DB write" → Core Rule → ARCH patch.
**Rule:** No capability is promoted to Core without Human Approval.

---

## Classification Types

When a project update enters the system, it is classified as one of:

| Type | Description | Destination |
|------|-------------|-------------|
| `PROJECT_SPECIFIC` | Data unique to one client | Client Business Pack only |
| `REUSABLE_CAPABILITY` | Pattern reusable across industries | Pending Capability Patch |
| `CORE_RULE` | Architectural or governance rule | Pending Core Memory Patch |
| `CLIENT_CONFIGURATION` | Settings/mapping for one client | Client Pack |
| `BUSINESS_PLAYBOOK` | How NEXUS enters a sector | Business Intake Knowledge Base |
| `DATA_IMPORT_PATTERN` | How data enters NEXUS from files | Capability → Data Intake Layer |
| `UI_PATTERN` | Reusable UI component or view | UI Library candidate |
| `AUTOMATION_PATTERN` | Repeatable automation flow | Automation Library candidate |
| `COMPLIANCE_GUARD` | A rule that prevents unsafe operations | Core Guard Layer |

---

## Maturity Levels

```
IDEA → DRAFT → PILOT → STABLE → REUSABLE_TEMPLATE → CORE_CAPABILITY → DEPRECATED
```

| Level | Meaning |
|-------|---------|
| `IDEA` | Not yet analyzed — raw learning input |
| `DRAFT` | Described but not implemented |
| `PILOT` | Implemented in one project (e.g. Omega) |
| `STABLE` | Tested, documented, reliable |
| `REUSABLE_TEMPLATE` | Packaged for other clients/sectors |
| `CORE_CAPABILITY` | Promoted into NEXUS Core — Human Approved |
| `DEPRECATED` | Replaced or retired |

---

## Promotion Flow

```
1. Project Update arrives → project_learning_ingest.py
2. System classifies update (9 types)
3. If REUSABLE_CAPABILITY or CORE_RULE:
   a. Compare against existing capabilities (similarity check)
   b. If similar → suggest MERGE (show diff)
   c. If new → create Pending Capability Patch
4. Patch enters review state (approval_status = PENDING)
5. Human reviews and approves
6. After approval:
   - nexus_capabilities.json updated
   - SQLite search index updated
   - Capability Registry updated
7. NEVER overwrite existing capability without showing diff first
```

---

## NEXUS Command Center Modes

### Mode 1 — Ask NEXUS Memory
Query NEXUS architecture decisions, rules, and core knowledge.
Backed by: `nexus_md_search.sqlite` + `nexus_md_index.json`

### Mode 2 — Business Intake Advisor
Input: "أنا في مصنع حلويات"
Output:
- What data NEXUS needs
- What files to upload
- Which capabilities apply
- Which are missing
- First 30-day plan
- How NEXUS adds operational value

### Mode 3 — Analyze Uploaded Company Files
Upload Excel/CSV company files.
NEXUS provides: data structure preview, field mapping suggestions, anomaly detection.
**Preview only — no DB write without approval.**

### Mode 4 — Project Learning Intake
When working in Omega or any project:
"سجل اللي اتعلمناه من تحديث Fleet P1"
System:
1. Summarizes the update
2. Classifies it (9 types)
3. Determines project-specific vs reusable
4. If reusable → creates Pending Capability Patch
5. Never commits without approval

### Mode 5 — Capability Registry
Shows all NEXUS capabilities with full metadata.
Fields: name, domain, status, maturity, source_project, reusable_for, required_data, suggested_tables, suggested_ui, risks, approval_status.

---

## Files in This Layer

| File | Role |
|------|------|
| `nexus_capabilities.json` | Master capability registry |
| `nexus_capability_schema.sql` | SQLite schema for capabilities + patches |
| `capability_registry.py` | Read, search, filter capabilities |
| `capability_promoter.py` | Approve/reject/promote patches |
| `project_learning_ingest.py` | Classify and process project updates |
| `NEXUS_CAPABILITY_ENGINE.md` | This document |
| `NEXUS_PROJECT_LEARNING_PROTOCOL.md` | Protocol for how projects teach NEXUS |
| `NEXUS_COMMANDER_CAPABILITY_UI_SPEC.md` | UI panel specification |

---

## API Endpoints (when backend exists)

```
GET  /api/nexus-capabilities                        → list all capabilities
POST /api/nexus-capabilities/search                 → search capabilities
POST /api/nexus-learning/ingest                     → ingest project update
POST /api/nexus-learning/create-capability-patch    → create pending patch
GET  /api/nexus-learning/patches                    → list pending patches
POST /api/nexus-learning/patches/:id/approve        → approve a patch
POST /api/nexus-business/intake                     → business intake advisor
POST /api/nexus-business/dna-preview                → file analysis preview
```

---

## Key Invariants

1. **Omega data never enters NEXUS Core.**
2. **No capability promoted without Human Approval.**
3. **Patch review always shows diff before overwrite.**
4. **Client configurations stay in Client Pack.**
5. **Source Truth and Causality Law apply to capability promotion.**
