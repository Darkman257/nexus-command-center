"""
NEXUS Architecture Memory Index Builder
Extracts structured records from NEXUS-MD xlsx and builds:
  1. nexus_memory.db  — SQLite + FTS5 full-text search
  2. nexus_index.json — Structured JSON for API / Supabase / RAG
"""

import json
import sqlite3
import re
from datetime import datetime
from openpyxl import load_workbook
from openpyxl.worksheet.formula import ArrayFormula

XL_PATH = "NEXUS-MD-1779391545198.xlsx"
DB_PATH  = "nexus_memory.db"
JSON_PATH = "nexus_index.json"

# ─────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────

def safe(v):
    """Return string value, None for empty/formula objects."""
    if v is None:
        return None
    if isinstance(v, ArrayFormula):
        return None
    s = str(v).strip()
    if not s or s.startswith("={") or s.startswith("=IF(") or s.startswith("=COLUMN"):
        return None
    return s

def load_rows(sheet):
    rows = []
    for row in sheet.iter_rows(values_only=False):
        d = {}
        for cell in row:
            v = safe(cell.value)
            if v is not None:
                d[cell.column - 1] = v  # 0-indexed
        if d:
            rows.append(d)
    return rows

def ts(v):
    if isinstance(v, datetime):
        return v.strftime("%Y-%m-%d")
    return str(v) if v else None

# ─────────────────────────────────────────────────
# RECORD EXTRACTORS
# ─────────────────────────────────────────────────

def extract_arch_records(rows):
    """
    ARCH entries are in the left block, cols 0-5.
    Pattern: col0 = ARCH-NNN, col1 = date, col2 = title, col3 = reason, col4 = impact, col5+ = layers
    """
    records = []
    arch_pattern = re.compile(r'^ARCH-\d{3}$')
    for row in rows:
        arch_id = row.get(0, "")
        if not arch_pattern.match(arch_id):
            continue
        layers = [row[k] for k in sorted(row.keys()) if k >= 5 and row[k] not in (row.get(0), row.get(1), row.get(2), row.get(3), row.get(4))]
        layers = [l for l in layers if l and len(l) < 50 and not l.startswith("ARCH") and not l.startswith("DEC")][:5]
        records.append({
            "id": arch_id,
            "type": "ARCH",
            "category": "Architecture Decision",
            "title": row.get(2, ""),
            "date": row.get(1, ""),
            "reason": row.get(3, ""),
            "impact": row.get(4, ""),
            "layers": layers,
            "tags": ["architecture", "decision"] + [l.lower() for l in layers if l],
            "content": f"{row.get(2,'')}. Reason: {row.get(3,'')}. Impact: {row.get(4,'')}. Layers: {', '.join(layers)}.",
        })
    return records


def extract_dec_records(rows):
    """
    DEC entries appear in col 7 block: col7=Decision ID (DEC-NNN), col8=date, col9=title,
    col10=rationale, col11=chosen solution, col12=context/problem, col13=rejected alt, col14=truth_status
    Also appears in cols 704-730 area for some rows.
    """
    records = []
    dec_pattern = re.compile(r'^DEC-\d{3}$')
    seen = set()

    # Primary position: col 7-14
    for row in rows:
        for base in [7, 704, 711, 719, 726, 803, 810]:
            dec_id = row.get(base, "")
            if not dec_pattern.match(str(dec_id)):
                continue
            if dec_id in seen:
                continue
            seen.add(dec_id)
            title        = row.get(base+1, row.get(base+2, ""))
            truth_status = row.get(base+2, row.get(base+3, ""))
            rationale    = row.get(base+3, row.get(base+4, ""))
            solution     = row.get(base+4, row.get(base+5, ""))
            problem      = row.get(base+5, row.get(base+6, ""))
            rejected     = row.get(base+6, row.get(base+7, ""))

            # Validate: title shouldn't look like a date or ID
            if not title or re.match(r'^\d{4}-\d{2}-\d{2}', title):
                title = row.get(base+2, "")

            truth_status_clean = truth_status if truth_status in ("STABLE", "EXPERIMENTAL", "DEPRECATED") else ""

            records.append({
                "id": dec_id,
                "type": "DEC",
                "category": "Architectural Decision Record",
                "title": title or dec_id,
                "truth_status": truth_status_clean,
                "rationale": rationale or "",
                "chosen_solution": solution or "",
                "context_problem": problem or "",
                "rejected_alternatives": rejected or "",
                "tags": ["decision", "adr", truth_status_clean.lower()],
                "content": f"{title}. Status: {truth_status_clean}. Rationale: {rationale}. Solution: {solution}. Problem: {problem}. Rejected: {rejected}.",
            })

    return records


def extract_dam_records(rows):
    """
    DAM table starts at row with col0='DAM-001'.
    Row 90 contains the full row inline: DAM-001 through DAM-004 side by side.
    """
    records = []
    dam_pattern = re.compile(r'^DAM-\d{3}$')
    seen = set()

    for row in rows:
        # Scan all cols for DAM-NNN
        for ci in range(0, 30):
            dam_id = row.get(ci, "")
            if not dam_pattern.match(str(dam_id)):
                continue
            if dam_id in seen:
                continue
            seen.add(dam_id)
            dec_type   = row.get(ci+1, "")
            authority  = row.get(ci+2, "")
            exec_mode  = row.get(ci+3, "")
            constraints= row.get(ci+4, "")
            stakeholder= row.get(ci+5, "")
            records.append({
                "id": dam_id,
                "type": "DAM",
                "category": "Decision Authority Matrix",
                "title": dec_type or dam_id,
                "authority_level": authority or "",
                "execution_mode": exec_mode or "",
                "constraints": constraints or "",
                "primary_stakeholder": stakeholder or "",
                "tags": ["dam", "guardrail", "governance", (exec_mode or "").lower()],
                "content": f"{dam_id}: {dec_type}. Authority: {authority}. Mode: {exec_mode}. Constraints: {constraints}. Stakeholder: {stakeholder}.",
            })

    return records


def extract_signals(rows):
    """
    Observability signals in row 1, cols 59-114 (current) and 742-797 (backup with live values).
    Pattern groups of 7: Signal, Meaning, Status, Value, Threshold, Escalation Rule, Truth Status
    """
    records = []
    # Row 0 (index 0) has the signal data in col 59 onwards
    if not rows:
        return records

    signal_row = rows[0]

    # Current telemetry block: starts at col 59
    # Groups of 7: [signal_name, meaning, status, value, threshold, escalation, truth_status]
    signal_names = []
    col = 59
    while col < 115:
        name = signal_row.get(col)
        if name and name not in ("Signal", "Meaning", "Status", "Value", "Threshold", "Escalation Rule", "Truth Status"):
            meaning    = signal_row.get(col+1, "")
            status     = signal_row.get(col+2, "")
            value      = signal_row.get(col+3, "")
            threshold  = signal_row.get(col+4, "")
            escalation = signal_row.get(col+5, "")
            truth_s    = signal_row.get(col+6, "")
            sig_id     = f"SIG-{len(records)+1:03d}"
            records.append({
                "id": sig_id,
                "type": "SIGNAL",
                "category": "Observability Telemetry",
                "title": name,
                "meaning": meaning,
                "status": status,
                "current_value": value,
                "threshold": threshold,
                "escalation_rule": escalation,
                "truth_status": truth_s,
                "tags": ["signal", "telemetry", "observability", (truth_s or "").lower(), (status or "").lower()],
                "content": f"Signal: {name}. Meaning: {meaning}. Status: {status}. Value: {value}. Threshold: {threshold}. Escalation: {escalation}. Truth: {truth_s}.",
            })
            col += 7
        else:
            col += 1

    return records


def extract_forbidden_directions(rows):
    """
    Row 47: FORBIDDEN DIRECTION (Anti-Patterns) inline in cols 3-18 and 702-703.
    Pattern: [anti-pattern, reason/risk, ARCH-ID, ...]
    """
    records = []
    for row in rows:
        if row.get(0, "") == "FORBIDDEN DIRECTION (Anti-Patterns)" and row.get(3):
            # cols 3, 4, 5 then 6,7,8 etc. groups of 3
            patterns = []
            for base in [3, 6, 9, 12, 15, 18, 702]:
                name    = row.get(base, "")
                reason  = row.get(base+1, "")
                arch_ref= row.get(base+2, "")
                if name and reason:
                    patterns.append({"name": name, "reason": reason, "arch_ref": arch_ref})
            for i, p in enumerate(patterns):
                records.append({
                    "id": f"FBD-{i+1:03d}",
                    "type": "FORBIDDEN",
                    "category": "Forbidden Direction / Anti-Pattern",
                    "title": p["name"],
                    "reason": p["reason"],
                    "arch_reference": p["arch_ref"],
                    "tags": ["forbidden", "anti-pattern", "architecture"],
                    "content": f"FORBIDDEN: {p['name']}. Risk: {p['reason']}. Ref: {p['arch_ref']}.",
                })
            break
    return records


def extract_cv_cover_rules(rows):
    """Rules from rows 71-78."""
    records = []
    rule_map = {
        "SOURCE TRUTH:": "SOURCE_TRUTH",
        "DERIVED TRUTH:": "DERIVED_TRUTH",
        "UI PROJECTION:": "UI_PROJECTION",
        "FORBIDDEN:": "FORBIDDEN",
        "FALLBACK RULE:": "FALLBACK",
        "PIPELINE RULE:": "PIPELINE",
        "FUTURE RULE:": "FUTURE",
    }
    for row in rows:
        text = row.get(0, "")
        for prefix, rtype in rule_map.items():
            if text.startswith(prefix):
                records.append({
                    "id": f"CVR-{rtype}",
                    "type": "CV_RULE",
                    "category": "Recruitment CV Cover Rule",
                    "title": rtype.replace("_", " "),
                    "rule": text,
                    "tags": ["recruitment", "cv", "rule", rtype.lower()],
                    "content": text,
                })
                break
    return records


def extract_repo_classification(rows):
    records = []
    # Row 55 has the categories inline
    for row in rows:
        if row.get(0) == "Communication Runtime" and row.get(2) == "Agent Architecture":
            cats = [
                (row.get(0), row.get(1)),
                (row.get(2), row.get(3)),
                (row.get(4), row.get(5)),
                (row.get(6), row.get(7)),
                (row.get(8), row.get(9)),
                (row.get(10), row.get(11)),
                (row.get(12), row.get(13)),
                (row.get(14), row.get(15)),
            ]
            for i, (cat, desc) in enumerate(cats):
                if cat:
                    records.append({
                        "id": f"REPO-CAT-{i+1:02d}",
                        "type": "REPO_CLASS",
                        "category": "Repository Classification",
                        "title": cat,
                        "description": desc or "",
                        "tags": ["repo", "classification", "architecture"],
                        "content": f"Category: {cat}. Description: {desc}.",
                    })
        if row.get(0) == "OpenWA" and row.get(1) and "Communication" in row.get(1,""):
            if not any(r["id"] == "REPO-P1-001" for r in records):
                pairs = [(row.get(i), row.get(i+1)) for i in range(0, 12, 2) if row.get(i)]
                for j, (name, role) in enumerate(pairs):
                    if name and role:
                        records.append({
                            "id": f"REPO-P1-{j+1:03d}",
                            "type": "REPO_STRATEGIC",
                            "category": "P1 Strategic Repository",
                            "title": name,
                            "strategic_role": role,
                            "tags": ["repo", "strategic", "p1"],
                            "content": f"Repo: {name}. Strategic role: {role}.",
                        })
    return records


def extract_decision_progression(rows):
    records = []
    stage_labels = {
        "Stage 1": ("Observability", "STABLE"),
        "Stage 2": ("Recommendations", "CURRENT / ACTIVE"),
        "Stage 3": ("Approval-Based Commands", "PLANNING"),
        "Stage 4": ("Limited Autonomous Execution", "FUTURE / RESEARCH"),
        "Stage 5": ("Adaptive Runtime Intelligence", "HYPOTHESIS"),
    }
    for row in rows:
        if row.get(0) in ("Stage 1", "Stage 2", "Stage 3", "Stage 4", "Stage 5") and row.get(0) not in [r["id"] for r in records]:
            stage = row.get(0)
            mode, status = stage_labels.get(stage, ("", ""))
            records.append({
                "id": f"STAGE-{stage[-1]}",
                "type": "STAGE",
                "category": "Decision Progression Stage",
                "title": f"{stage}: {mode}",
                "mode": mode,
                "status": status,
                "tags": ["stage", "progression", "autonomy", status.lower().split("/")[0].strip()],
                "content": f"{stage}: {mode}. Current status: {status}.",
            })
    # Also get the canonical row with all 5 stages
    for row in rows:
        if row.get(0) == "Stage 1" and row.get(3) == "Stage 2":
            for i, (stage_col, mode_col, status_col) in enumerate([(0,1,2),(3,4,5),(6,7,8),(9,10,11),(12,13,14)]):
                s = row.get(stage_col, "")
                m = row.get(mode_col, "")
                st = row.get(status_col, "")
                if s and s not in [r["id"] for r in records]:
                    records.append({
                        "id": f"STAGE-{i+1}",
                        "type": "STAGE",
                        "category": "Decision Progression Stage",
                        "title": f"{s}: {m}",
                        "mode": m,
                        "status": st,
                        "tags": ["stage", "progression", "autonomy"],
                        "content": f"{s}: {m}. Status: {st}.",
                    })
            break
    return records


def extract_truth_types(rows):
    truth_types = [
        ("TRUTH-SOURCE", "**SOURCE TRUTH**", "SOURCE TRUTH", "Original, raw operational data that has not been derived or computed."),
        ("TRUTH-DERIVED", "**DERIVED TRUTH**", "DERIVED TRUTH", "Dynamically calculated or computed from source truth data."),
        ("TRUTH-INFERENCE", "**INFERENCE**", "INFERENCE", "AI or logic-based deduction from existing data."),
        ("TRUTH-UI", "**UI PROJECTION**", "UI PROJECTION", "Visual-only surface data for display purposes, never stored as source."),
    ]
    records = []
    for row in rows:
        for tid, key, label, default_desc in truth_types:
            if row.get(0) == key:
                records.append({
                    "id": tid,
                    "type": "TRUTH_TYPE",
                    "category": "Truth Classification System",
                    "title": label,
                    "description": row.get(1, default_desc),
                    "example_field": row.get(2, ""),
                    "tags": ["truth", "classification", "memory", label.lower().replace(" ", "_")],
                    "content": f"{label}: {row.get(1, default_desc)}. Example: {row.get(2, '')}.",
                })
    return records


def extract_impl_log(rows):
    records = []
    in_log = False
    for row in rows:
        if row.get(0) == "RECRUITMENT HUB IMPLEMENTATION LOG":
            in_log = True
            continue
        if in_log and row.get(0) == "Implementation ID":
            continue
        if in_log and row.get(0, "").startswith(("RH-", "OMG-")):
            impl_id = row.get(0, "")
            records.append({
                "id": impl_id,
                "type": "IMPL",
                "category": "Implementation Log",
                "title": f"{row.get(2, '')} — {row.get(3, '')}",
                "hub": row.get(2, ""),
                "feature": row.get(3, ""),
                "status": row.get(4, row.get(6, "")),
                "build": row.get(9, row.get(17, "")),
                "db_change": row.get(10, row.get(18, "")),
                "git_state": row.get(11, row.get(19, "")),
                "risk": row.get(12, row.get(20, "")),
                "next_action": row.get(13, row.get(21, "")),
                "tags": ["implementation", "log", "git", (row.get(2) or "").lower()],
                "content": f"ID: {impl_id}. Hub: {row.get(2,'')}. Feature: {row.get(3,'')}. Status: {row.get(4, row.get(6,''))}.",
            })
    return records


# ─────────────────────────────────────────────────
# MAIN PIPELINE
# ─────────────────────────────────────────────────

def build_index():
    print("Loading workbook...")
    wb = load_workbook(XL_PATH, read_only=False, data_only=True)
    ws = wb["Sheet1"]
    rows = load_rows(ws)
    print(f"  {len(rows)} non-empty rows loaded.")

    all_records = []

    extractors = [
        ("Architecture Decisions",     extract_arch_records),
        ("Architectural Decision Records", extract_dec_records),
        ("Decision Authority Matrix",  extract_dam_records),
        ("Observability Signals",      extract_signals),
        ("Forbidden Directions",       extract_forbidden_directions),
        ("CV Cover Rules",             extract_cv_cover_rules),
        ("Repo Classification",        extract_repo_classification),
        ("Decision Progression Stages",extract_decision_progression),
        ("Truth Type Definitions",     extract_truth_types),
        ("Implementation Log",         extract_impl_log),
    ]

    for label, fn in extractors:
        recs = fn(rows)
        print(f"  [{label}] → {len(recs)} records")
        all_records.extend(recs)

    print(f"\nTotal records: {len(all_records)}")

    # Deduplicate by id
    seen_ids = set()
    deduped = []
    for r in all_records:
        if r["id"] not in seen_ids:
            seen_ids.add(r["id"])
            deduped.append(r)
    print(f"After dedup: {len(deduped)} records")

    # ── JSON OUTPUT ──────────────────────────────
    index = {
        "meta": {
            "source": XL_PATH,
            "generated_at": datetime.now().isoformat(),
            "total_records": len(deduped),
            "record_types": sorted(set(r["type"] for r in deduped)),
        },
        "records": deduped,
    }
    with open(JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(index, f, ensure_ascii=False, indent=2)
    print(f"\n✓ JSON index written → {JSON_PATH}")

    # ── SQLITE + FTS5 OUTPUT ─────────────────────
    import os
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)

    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()

    # Main records table
    cur.execute("""
        CREATE TABLE records (
            id            TEXT PRIMARY KEY,
            type          TEXT NOT NULL,
            category      TEXT,
            title         TEXT,
            content       TEXT,
            tags          TEXT,
            json_data     TEXT,
            created_at    TEXT DEFAULT (datetime('now'))
        )
    """)

    # FTS5 virtual table
    cur.execute("""
        CREATE VIRTUAL TABLE records_fts USING fts5(
            id,
            type,
            category,
            title,
            content,
            tags,
            content='records',
            content_rowid='rowid'
        )
    """)

    for r in deduped:
        tags_str = " ".join(r.get("tags", []))
        cur.execute(
            "INSERT INTO records (id, type, category, title, content, tags, json_data) VALUES (?,?,?,?,?,?,?)",
            (r["id"], r["type"], r["category"], r["title"], r["content"], tags_str, json.dumps(r, ensure_ascii=False))
        )

    # Populate FTS5
    cur.execute("""
        INSERT INTO records_fts (rowid, id, type, category, title, content, tags)
        SELECT rowid, id, type, category, title, content, tags FROM records
    """)

    # Stats view
    cur.execute("""
        CREATE VIEW stats AS
        SELECT type, category, COUNT(*) as count FROM records GROUP BY type, category ORDER BY count DESC
    """)

    con.commit()
    con.close()
    print(f"✓ SQLite + FTS5 database written → {DB_PATH}")

    # Summary
    from collections import Counter
    type_counts = Counter(r["type"] for r in deduped)
    print("\n── Index Summary ─────────────────────────────")
    for t, c in sorted(type_counts.items()):
        print(f"  {t:<20} {c:>3} records")
    print("──────────────────────────────────────────────")

    return deduped

if __name__ == "__main__":
    build_index()
